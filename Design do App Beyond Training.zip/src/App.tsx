import { useEffect, useState, type ReactNode } from 'react'

/* ---------- persistência local (sem back-end ainda) ---------- */
function useStore<T>(key: string, init: T) {
  const [v, set] = useState<T>(() => {
    try { const s = localStorage.getItem('bt:' + key); return s ? JSON.parse(s) : init } catch { return init }
  })
  useEffect(() => { localStorage.setItem('bt:' + key, JSON.stringify(v)) }, [key, v])
  return [v, set] as const
}
const uid = () => Math.random().toString(36).slice(2, 9)
const iso = (d = new Date()) => d.toISOString().slice(0, 10)
const DAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']

/* ---------- ícones ---------- */
const P: Record<string, string> = {
  home: 'M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z',
  food: 'M12 7c-3-2-7 0-7 5 0 4 3 9 7 7 4 2 7-3 7-7 0-5-4-7-7-5zM12 7c0-2 1-3 3-4',
  prog: 'M4 19V5M4 19h16M8 15l4-5 3 3 5-7',
  check: 'M12 21a9 9 0 100-18 9 9 0 000 18zM8 12l3 3 5-6',
  me: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  mail: 'M3 6h18v12H3zM3 7l9 7 9-7',
  lock: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3',
  pin: 'M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11zM12 12a2 2 0 100-4 2 2 0 000 4z',
  back: 'M15 5l-7 7 7 7',
  right: 'M9 5l7 7-7 7',
  plus: 'M12 5v14M5 12h14',
  trash: 'M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13',
  send: 'M4 12l16-8-6 16-3-6z',
  cog: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1-2-1-1-2h-4l-1 2-2 1-2-1-2 4 2 1v2l-2 1 2 4 2-1 2 1 1 2h4l1-2 2-1 2 1 2-4-2-1z',
  bell: 'M6 16V11a6 6 0 0112 0v5l2 2H4zM10 21h4',
  dumb: 'M6 7v10M18 7v10M3 10v4M21 10v4M6 12h12',
}
const Ic = ({ n, s = 20 }: { n: string; s?: number }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d={P[n]} /></svg>
)

/* ---------- primitivos ---------- */
const Box = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div className={`rounded-lg border border-line bg-surface p-3 ${className}`}>{children}</div>
)
const Btn = ({ children, className = '', ...p }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button {...p} className={`h-11 rounded-md bg-accent px-4 text-sm font-semibold text-white active:opacity-80 disabled:opacity-40 ${className}`}>{children}</button>
)
const Field = ({ icon, ...p }: { icon?: string } & React.InputHTMLAttributes<HTMLInputElement>) => (
  <label className="flex h-11 items-center gap-2 rounded-md border border-line bg-surface px-3 text-mute focus-within:border-bright">
    {icon && <Ic n={icon} s={16} />}
    <input {...p} className="h-full flex-1 bg-transparent text-sm text-ink outline-none placeholder:text-mute" />
  </label>
)
const Title = ({ children, back }: { children: ReactNode; back?: () => void }) => (
  <div className="mb-4 flex items-center gap-2">
    {back && <button onClick={back} aria-label="Voltar" className="-ml-2 flex h-10 w-10 items-center justify-center"><Ic n="back" /></button>}
    <h1 className="text-xl font-bold">{children}</h1>
  </div>
)
const Sub = ({ children }: { children: ReactNode }) => <h2 className="mb-2 mt-5 text-sm font-semibold">{children}</h2>
const Empty = ({ children }: { children: ReactNode }) => <p className="rounded-lg border border-dashed border-line p-4 text-center text-xs text-mute">{children}</p>

/* ---------- tipos ---------- */
type User = { name: string; email: string; pass: string }
type Meal = { id: string; date: string; name: string; desc: string; kcal: number; p: number; c: number; f: number }
type Rec = { id: string; date: string; kg: number; fat?: number }
type Ex = { id: string; name: string; sets: number; reps: number; kg: number; rest: number }
type Workout = { id: string; name: string; exercises: Ex[] }
type Gym = { name: string; addr: string; q: string }
type Page = 'home' | 'food' | 'prog' | 'check' | 'me' | 'train' | 'chat' | 'settings' | 'gyms'

const GYMS: Gym[] = [
  { name: 'MetaFit', addr: 'R. Pio IX, Nº 85 – Bairro Vila São Luiz', q: 'MetaFit academia' },
  { name: 'BusterFit', addr: 'Rua Tróia, nº 400, 224, – Centro', q: 'BusterFit academia' },
]
const WARM = ['Esteira leve 5–10 min', 'Mobilidade de ombros e quadril', 'Série de aquecimento com 50% da carga']
const SUGG: Workout[] = [
  { id: 's1', name: 'Peito e Tríceps', exercises: [
    { id: 'a', name: 'Supino reto', sets: 4, reps: 10, kg: 40, rest: 90 }, { id: 'b', name: 'Crucifixo', sets: 3, reps: 12, kg: 12, rest: 60 }, { id: 'c', name: 'Tríceps corda', sets: 3, reps: 12, kg: 20, rest: 60 }] },
  { id: 's2', name: 'Costas e Bíceps', exercises: [
    { id: 'a', name: 'Puxada frontal', sets: 4, reps: 10, kg: 45, rest: 90 }, { id: 'b', name: 'Remada baixa', sets: 3, reps: 12, kg: 40, rest: 60 }, { id: 'c', name: 'Rosca direta', sets: 3, reps: 10, kg: 15, rest: 60 }] },
  { id: 's3', name: 'Pernas', exercises: [
    { id: 'a', name: 'Agachamento', sets: 4, reps: 8, kg: 60, rest: 120 }, { id: 'b', name: 'Leg press', sets: 4, reps: 12, kg: 120, rest: 90 }, { id: 'c', name: 'Cadeira extensora', sets: 3, reps: 12, kg: 35, rest: 60 }] },
]
const GROUPS: Record<string, string[]> = {
  Peito: ['Supino reto', 'Supino inclinado', 'Crucifixo'], Costas: ['Puxada frontal', 'Remada baixa', 'Remada curvada'],
  Ombros: ['Desenvolvimento', 'Elevação lateral'], Braços: ['Rosca direta', 'Tríceps corda', 'Rosca martelo'],
  Pernas: ['Agachamento', 'Leg press', 'Cadeira extensora', 'Mesa flexora'], Abdômen: ['Prancha', 'Abdominal infra'],
}

/* ---------- Login / Cadastro ---------- */
function Auth({ users, setUsers, login }: { users: User[]; setUsers: (u: User[]) => void; login: (e: string) => void }) {
  const [mode, setMode] = useState<'in' | 'up'>('in')
  const [f, setF] = useState({ name: '', email: '', pass: '', pass2: '' })
  const [err, setErr] = useState('')
  const [info, setInfo] = useState('')
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setErr(''); setInfo('')
    const email = f.email.trim().toLowerCase()
    if (mode === 'up') {
      if (f.pass.length < 8) return setErr('A senha precisa ter ao menos 8 caracteres.')
      if (f.pass !== f.pass2) return setErr('As senhas não coincidem.')
      if (users.some((u) => u.email === email)) return setErr('Este e-mail já está cadastrado.')
      setUsers([...users, { name: f.name.trim(), email, pass: f.pass }]); login(email)
    } else {
      const u = users.find((x) => x.email === email && x.pass === f.pass)
      if (!u) return setErr('E-mail ou senha incorretos.')
      login(email)
    }
  }
  return (
    <form onSubmit={submit} className="flex h-full flex-col justify-center gap-3 px-8">
      <div className="mx-auto mb-1 flex h-20 w-20 items-center justify-center rounded-full bg-ink text-bg"><Ic n="dumb" s={34} /></div>
      <p className="text-center text-xs font-semibold tracking-wide">BEM-VINDO!</p>
      <p className="text-center text-xs text-mute">{mode === 'in' ? 'Entre na sua conta para continuar' : 'Faça o seu cadastro!'}</p>
      {mode === 'up' && <Field icon="me" required placeholder="Nome" aria-label="Nome" value={f.name} onChange={set('name')} />}
      <Field icon="mail" required type="email" placeholder="E-mail" aria-label="E-mail" value={f.email} onChange={set('email')} />
      <Field icon="lock" required type="password" placeholder="Senha" aria-label="Senha" value={f.pass} onChange={set('pass')} />
      {mode === 'up' && <Field icon="lock" required type="password" placeholder="Confirmar senha" aria-label="Confirmar senha" value={f.pass2} onChange={set('pass2')} />}
      {mode === 'in' && <button type="button" onClick={() => setInfo('Recuperação por e-mail exige o servidor, ainda não implementado.')} className="self-end text-[11px] text-mute underline">Esqueci minha senha?</button>}
      {err && <p role="alert" className="text-xs text-bad">{err}</p>}
      {info && <p className="text-xs text-warn">{info}</p>}
      <Btn type="submit">{mode === 'in' ? 'Entrar' : 'Cadastrar'}</Btn>
      <button type="button" onClick={() => { setMode(mode === 'in' ? 'up' : 'in'); setErr('') }} className="text-center text-[11px] text-mute">
        {mode === 'in' ? 'Não tem uma conta? ' : 'Já tem conta? '}<span className="font-semibold text-ink underline">{mode === 'in' ? 'Cadastre-se' : 'Entrar'}</span>
      </button>
      <p className="text-center text-[10px] text-mute">Dados salvos apenas neste aparelho (protótipo). Ao continuar, você concorda com o uso dos dados conforme a LGPD.</p>
    </form>
  )
}

/* ---------- Home ---------- */
function Home({ u, go, checks, today, meals }: { u: User; go: (p: Page) => void; checks: string[]; today: string; meals: Meal[] }) {
  const kcal = meals.filter((m) => m.date === today).reduce((a, m) => a + m.kcal, 0)
  const done = checks.includes(today)
  return (
    <div>
      <h1 className="text-xl font-bold">Olá, {u.name.split(' ')[0]}!</h1>
      <p className="mb-5 text-xs text-mute">Traça os próximos e melhor os resultados.</p>
      <h2 className="mb-2 text-sm font-semibold">Destaques</h2>
      <Box className="grid grid-cols-3 divide-x divide-line py-4 text-center">
        <button onClick={() => go('food')}><p className="text-lg font-bold">{kcal}</p><p className="text-[10px] text-mute">kcal hoje</p></button>
        <button onClick={() => go('check')}><p className="text-lg font-bold">{done ? 'Feito' : 'Pendente'}</p><p className="text-[10px] text-mute">check-in</p></button>
        <button onClick={() => go('train')}><p className="text-lg font-bold">Treino</p><p className="text-[10px] text-mute">ver sugestões</p></button>
      </Box>
      <h2 className="mb-2 mt-6 text-sm font-semibold">Academias próximas</h2>
      <div className="space-y-2"><Gyms /></div>
      <button onClick={() => go('gyms')} className="mt-2 text-xs text-mute underline">Ver todas</button>
    </div>
  )
}
function Gyms({ onCheck }: { onCheck?: () => void } = {}) {
  const [msg, setMsg] = useState('')
  return (
    <>
      {GYMS.map((g) => (
        <Box key={g.name}>
          <div className="flex gap-2"><span className="mt-0.5 text-mute"><Ic n="pin" s={16} /></span>
            <div className="flex-1"><p className="text-sm font-semibold">{g.name}</p><p className="text-[10px] text-mute">{g.addr}</p>
              <div className="mt-2 flex gap-2">
                <a target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/${encodeURIComponent(g.q)}`} className="flex h-8 flex-1 items-center justify-center rounded-full border border-line text-[11px]">Mapa</a>
                <button onClick={() => { onCheck?.(); setMsg(`Check-in registrado em ${g.name}.`) }} className="h-8 flex-1 rounded-full border border-line text-[11px]">Espiar Check-in</button>
              </div></div></div>
        </Box>
      ))}
      {msg && <p role="status" className="text-xs text-ok">{msg}</p>}
    </>
  )
}

/* ---------- Nutrição ---------- */
function Food({ meals, setMeals, today }: { meals: Meal[]; setMeals: (m: Meal[]) => void; today: string }) {
  const [day, setDay] = useState(today)
  const [open, setOpen] = useState(false)
  const [f, setF] = useState({ name: '', desc: '', kcal: '', p: '', c: '', f: '' })
  const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - d.getDay() + i); return d })
  const list = meals.filter((m) => m.date === day)
  const tot = list.reduce((a, m) => ({ k: a.k + m.kcal, p: a.p + m.p, c: a.c + m.c, f: a.f + m.f }), { k: 0, p: 0, c: 0, f: 0 })
  const add = (e: React.FormEvent) => {
    e.preventDefault()
    setMeals([...meals, { id: uid(), date: day, name: f.name, desc: f.desc, kcal: +f.kcal, p: +f.p || 0, c: +f.c || 0, f: +f.f || 0 }])
    setF({ name: '', desc: '', kcal: '', p: '', c: '', f: '' }); setOpen(false)
  }
  const n = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })
  return (
    <div>
      <Title>Nutrição</Title>
      <div className="mb-4 flex justify-between text-[11px]">
        {week.map((d) => <button key={iso(d)} onClick={() => setDay(iso(d))} className={`flex h-12 w-10 flex-col items-center justify-center rounded-md ${day === iso(d) ? 'bg-accent text-white' : 'text-mute'}`}>{DAYS[d.getDay()]}<span className="font-bold">{d.getDate()}</span></button>)}
      </div>
      <Box className="mb-3">
        <p className="text-2xl font-bold">{tot.k}<span className="text-xs font-normal text-mute"> kcal</span></p>
        <div className="mt-2 grid grid-cols-3 gap-2 text-center text-[11px]">
          {[['Proteína', tot.p], ['Carbo', tot.c], ['Gordura', tot.f]].map(([l, v]) => <div key={l} className="rounded-md bg-surface2 py-2"><p className="text-sm font-bold">{v} g</p><p className="text-mute">{l}</p></div>)}
        </div>
      </Box>
      <div className="space-y-2">
        {list.length === 0 && <Empty>Nenhuma refeição registrada neste dia.</Empty>}
        {list.map((m) => (
          <Box key={m.id} className="flex items-center gap-3">
            <div className="flex-1"><p className="text-sm font-semibold">{m.name}</p><p className="text-[10px] text-mute">{m.desc || `P ${m.p} · C ${m.c} · G ${m.f}`}</p></div>
            <span className="text-xs font-bold">{m.kcal} kcal</span>
            <button aria-label={`Excluir ${m.name}`} onClick={() => setMeals(meals.filter((x) => x.id !== m.id))} className="flex h-9 w-9 items-center justify-center text-mute"><Ic n="trash" s={16} /></button>
          </Box>
        ))}
      </div>
      {open ? (
        <form onSubmit={add} className="mt-3 space-y-2">
          <Field required placeholder="Refeição (ex.: Café da manhã)" aria-label="Refeição" value={f.name} onChange={n('name')} />
          <Field placeholder="Alimentos (opcional)" aria-label="Alimentos" value={f.desc} onChange={n('desc')} />
          <div className="grid grid-cols-4 gap-2">
            <Field required type="number" min="0" placeholder="kcal" aria-label="Calorias" value={f.kcal} onChange={n('kcal')} />
            <Field type="number" min="0" placeholder="P g" aria-label="Proteínas" value={f.p} onChange={n('p')} />
            <Field type="number" min="0" placeholder="C g" aria-label="Carboidratos" value={f.c} onChange={n('c')} />
            <Field type="number" min="0" placeholder="G g" aria-label="Gorduras" value={f.f} onChange={n('f')} />
          </div>
          <div className="flex gap-2"><Btn type="submit" className="flex-1">Salvar</Btn><Btn type="button" onClick={() => setOpen(false)} className="bg-surface2">Cancelar</Btn></div>
        </form>
      ) : <Btn onClick={() => setOpen(true)} className="mt-3 flex w-full items-center justify-center gap-2"><Ic n="plus" s={16} />Registrar refeição</Btn>}
      <p className="mt-2 text-[10px] text-mute">Valores informados por você. Não substitui orientação de nutricionista.</p>
    </div>
  )
}

/* ---------- Treino ---------- */
function Train({ mine, setMine, checkin, back }: { mine: Workout[]; setMine: (w: Workout[]) => void; checkin: () => void; back: () => void }) {
  const [sel, setSel] = useState<Workout | null>(null)
  const [creating, setCreating] = useState(false)
  const [name, setName] = useState('')
  const [grp, setGrp] = useState<string | null>(null)
  const [done, setDone] = useState<string[]>([])

  if (sel) {
    const mineIdx = mine.findIndex((w) => w.id === sel.id)
    const upd = (ex: Ex[]) => { const w = { ...sel, exercises: ex }; setSel(w); if (mineIdx >= 0) setMine(mine.map((x) => (x.id === w.id ? w : x))) }
    const edit = (id: string, k: keyof Ex, v: number) => upd(sel.exercises.map((e) => (e.id === id ? { ...e, [k]: v } : e)))
    return (
      <div>
        <Title back={() => { setSel(null); setDone([]) }}>{sel.name}</Title>
        <div className="space-y-2">
          {sel.exercises.map((e) => (
            <Box key={e.id}>
              <div className="flex items-center justify-between"><p className="text-sm font-semibold">{e.name}</p>
                <button onClick={() => setDone(done.includes(e.id) ? done.filter((x) => x !== e.id) : [...done, e.id])} aria-pressed={done.includes(e.id)} aria-label="Concluir exercício" className={done.includes(e.id) ? 'text-ok' : 'text-mute'}><Ic n="check" s={22} /></button></div>
              <div className="mt-2 grid grid-cols-4 gap-2 text-[10px] text-mute">
                {([['sets', 'Séries'], ['reps', 'Reps'], ['kg', 'Carga kg'], ['rest', 'Desc. s']] as const).map(([k, l]) => (
                  <label key={k}>{l}<input type="number" min="0" value={e[k]} onChange={(ev) => edit(e.id, k, +ev.target.value)} className="mt-1 h-9 w-full rounded-md border border-line bg-bg px-2 text-sm text-ink" /></label>
                ))}
              </div>
              {mineIdx >= 0 && <button onClick={() => upd(sel.exercises.filter((x) => x.id !== e.id))} className="mt-2 text-[11px] text-bad">Remover</button>}
            </Box>
          ))}
        </div>
        {mineIdx >= 0 && (<><Sub>Adicionar exercício</Sub>
          <div className="mb-2 flex flex-wrap gap-2">{Object.keys(GROUPS).map((g) => <button key={g} onClick={() => setGrp(g)} className={`h-8 rounded-full border px-3 text-[11px] ${grp === g ? 'border-bright text-ink' : 'border-line text-mute'}`}>{g}</button>)}</div>
          {grp && <div className="space-y-1">{GROUPS[grp].map((x) => <button key={x} onClick={() => upd([...sel.exercises, { id: uid(), name: x, sets: 3, reps: 10, kg: 0, rest: 60 }])} className="flex h-10 w-full items-center justify-between rounded-md border border-line px-3 text-xs">{x}<Ic n="plus" s={14} /></button>)}</div>}</>)}
        <Btn disabled={!sel.exercises.length || done.length < sel.exercises.length} onClick={() => { checkin(); setSel(null); setDone([]) }} className="mt-5 w-full">
          Concluir treino ({done.length}/{sel.exercises.length})
        </Btn>
        <p className="mt-1 text-center text-[10px] text-mute">Treino concluído = todos os exercícios marcados. Isso registra o check-in do dia.</p>
      </div>
    )
  }
  return (
    <div>
      <Title back={back}>Treinos</Title>
      <Box><p className="text-sm font-semibold">Aquecimento</p><p className="mb-1 text-[10px] text-mute">5 a 10 minutos</p>
        <ul className="list-disc space-y-0.5 pl-4 text-xs text-mute">{WARM.map((w) => <li key={w}>{w}</li>)}</ul></Box>
      <Sub>Meus treinos</Sub>
      <div className="space-y-2">
        {mine.length === 0 && <Empty>Você ainda não criou treinos.</Empty>}
        {mine.map((w) => (
          <Box key={w.id} className="flex items-center">
            <button onClick={() => setSel(w)} className="flex-1 text-left"><p className="text-sm font-semibold">{w.name}</p><p className="text-[10px] text-mute">{w.exercises.length} exercícios</p></button>
            <button aria-label={`Excluir ${w.name}`} onClick={() => setMine(mine.filter((x) => x.id !== w.id))} className="flex h-9 w-9 items-center justify-center text-mute"><Ic n="trash" s={16} /></button>
          </Box>
        ))}
      </div>
      {creating ? (
        <form onSubmit={(e) => { e.preventDefault(); const w = { id: uid(), name, exercises: [] }; setMine([...mine, w]); setName(''); setCreating(false); setSel(w) }} className="mt-2 flex gap-2">
          <Field required autoFocus placeholder="Nome do treino" aria-label="Nome do treino" value={name} onChange={(e) => setName(e.target.value)} /><Btn type="submit">Criar</Btn>
        </form>
      ) : <Btn onClick={() => setCreating(true)} className="mt-2 w-full">Novo treino</Btn>}
      <Sub>Sugestão de Treinos</Sub>
      <div className="space-y-2">
        {SUGG.map((w) => (
          <Box key={w.id} className="flex items-center">
            <button onClick={() => setSel(w)} className="flex-1 text-left"><p className="text-sm font-semibold">{w.name}</p><p className="text-[10px] text-mute">{w.exercises.map((e) => e.name).join(' · ')}</p></button>
            <Btn onClick={() => setMine([...mine, { ...w, id: uid() }])} className="h-8 bg-surface2 px-3 text-[11px]">Salvar</Btn>
          </Box>
        ))}
      </div>
    </div>
  )
}

/* ---------- Check-in ---------- */
function Check({ checks, setChecks, today, go }: { checks: string[]; setChecks: (c: string[]) => void; today: string; go: (p: Page) => void }) {
  const week = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - d.getDay() + i); return d })
  const cnt = week.filter((d) => checks.includes(iso(d))).length
  const done = checks.includes(today)
  const status = cnt >= 4 ? ['Boa frequência', 'bg-ok'] : cnt >= 2 ? ['Atenção', 'bg-warn'] : ['Baixa frequência', 'bg-bad']
  return (
    <div>
      <Title>Check-in</Title>
      <p className="-mt-3 mb-4 text-[11px] text-mute">Registre a sua constância.</p>
      <div className="flex justify-between">
        {week.map((d) => { const k = iso(d), on = checks.includes(k); return (
          <button key={k} aria-label={`${DAYS[d.getDay()]} ${d.getDate()}`} aria-pressed={on} onClick={() => setChecks(on ? checks.filter((x) => x !== k) : [...checks, k])} className="flex flex-col items-center gap-2 text-[10px] text-mute">
            {DAYS[d.getDay()][0]}<span className={`flex h-8 w-8 items-center justify-center rounded-full ${on ? 'bg-accent text-white' : k === today ? 'border border-bright' : 'bg-surface'}`}>{on && <Ic n="check" s={14} />}</span></button>) })}
      </div>
      <Sub>Frequência semanal</Sub>
      <Box className="flex h-32 items-end justify-between px-4">
        {week.map((d) => <div key={iso(d)} className="flex flex-col items-center gap-1 text-[10px] text-mute"><div className={`w-3 rounded-sm ${checks.includes(iso(d)) ? 'h-16 bg-ink' : 'h-2 bg-line'}`} />{DAYS[d.getDay()]}</div>)}
      </Box>
      <div className="mt-3 space-y-1 text-xs"><p className="flex items-center gap-2"><span className={`h-3 w-3 rounded-full ${status[1]}`} />{status[0]}: {cnt} treino(s) nesta semana</p></div>
      <Btn disabled={done} onClick={() => setChecks([...checks, today])} className="mt-4 w-full">{done ? 'Check-in de hoje registrado' : 'Fazer check-in de hoje'}</Btn>
      <button onClick={() => go('train')} className="mt-2 h-11 w-full rounded-md border border-line text-sm">Ir para treinos</button>
    </div>
  )
}

/* ---------- Evolução ---------- */
function Line({ data, unit, label }: { data: { x: string; y: number }[]; unit: string; label: string }) {
  if (data.length < 2) return <Empty>Registre ao menos 2 medições para ver o gráfico.</Empty>
  const ys = data.map((d) => d.y), mn = Math.min(...ys) - 1, mx = Math.max(...ys) + 1
  const pts = data.map((d, i) => `${20 + (i / (data.length - 1)) * 270},${95 - ((d.y - mn) / (mx - mn)) * 85}`).join(' ')
  return (
    <svg viewBox="0 0 300 120" className="w-full" role="img" aria-label={`${label}: de ${ys[0]} a ${ys[ys.length - 1]} ${unit}`}>
      {[0, 1, 2].map((i) => <line key={i} x1="20" x2="290" y1={10 + i * 42} y2={10 + i * 42} stroke="#232f55" strokeWidth="0.5" />)}
      <text x="0" y="14" fontSize="8" fill="#8592b3">{mx.toFixed(0)}</text><text x="0" y="98" fontSize="8" fill="#8592b3">{mn.toFixed(0)}</text>
      <polyline points={pts} fill="none" stroke="#6f8ff0" strokeWidth="1.8" strokeLinejoin="round" />
      {data.map((d, i) => <circle key={i} cx={20 + (i / (data.length - 1)) * 270} cy={95 - ((d.y - mn) / (mx - mn)) * 85} r="2.5" fill="#eef2fb" />)}
      <text x="20" y="114" fontSize="8" fill="#8592b3">{data[0].x}</text><text x="290" y="114" fontSize="8" textAnchor="end" fill="#8592b3">{data[data.length - 1].x}</text>
    </svg>
  )
}
function Prog({ recs, setRecs }: { recs: Rec[]; setRecs: (r: Rec[]) => void }) {
  const [tab, setTab] = useState<'g' | 'h'>('g')
  const [f, setF] = useState({ date: iso(), kg: '', fat: '' })
  const sorted = [...recs].sort((a, b) => a.date.localeCompare(b.date))
  const fmt = (d: string) => d.slice(8) + '/' + d.slice(5, 7)
  const add = (e: React.FormEvent) => {
    e.preventDefault()
    const rest = recs.filter((r) => r.date !== f.date) // evita duplicidade por dia
    setRecs([...rest, { id: uid(), date: f.date, kg: +f.kg, fat: f.fat ? +f.fat : undefined }]); setF({ ...f, kg: '', fat: '' })
  }
  return (
    <div>
      <Title>Evolução</Title>
      <div className="mb-4 grid grid-cols-2 rounded-md border border-line p-0.5 text-xs">
        {([['g', 'Gráficos'], ['h', 'Histórico']] as const).map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`h-8 rounded ${tab === k ? 'bg-accent text-white' : 'text-mute'}`}>{l}</button>)}
      </div>
      {tab === 'g' ? (<>
        <p className="text-sm font-semibold">Peso (kg)</p>
        <Line label="Peso" unit="kg" data={sorted.map((r) => ({ x: fmt(r.date), y: r.kg }))} />
        <p className="mt-4 text-sm font-semibold">% Gordura</p>
        <Line label="Gordura" unit="%" data={sorted.filter((r) => r.fat != null).map((r) => ({ x: fmt(r.date), y: r.fat! }))} />
      </>) : (
        <div className="space-y-2">
          {sorted.length === 0 && <Empty>Sem registros ainda.</Empty>}
          {[...sorted].reverse().map((r) => (
            <Box key={r.id} className="flex items-center justify-between text-sm"><span>{fmt(r.date)}</span><span>{r.kg} kg{r.fat != null && ` · ${r.fat}%`}</span>
              <button aria-label="Excluir registro" onClick={() => setRecs(recs.filter((x) => x.id !== r.id))} className="text-mute"><Ic n="trash" s={16} /></button></Box>
          ))}
        </div>
      )}
      <Sub>Nova medição</Sub>
      <form onSubmit={add} className="grid grid-cols-3 gap-2">
        <Field required type="date" max={iso()} aria-label="Data" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
        <Field required type="number" step="0.1" min="20" max="400" placeholder="Peso kg" aria-label="Peso" value={f.kg} onChange={(e) => setF({ ...f, kg: e.target.value })} />
        <Field type="number" step="0.1" min="2" max="70" placeholder="% gord." aria-label="Percentual de gordura" value={f.fat} onChange={(e) => setF({ ...f, fat: e.target.value })} />
        <Btn type="submit" className="col-span-3">Salvar medição</Btn>
      </form>
    </div>
  )
}

/* ---------- Perfil / Chat / Configurações ---------- */
function Me({ u, go, logout, checks }: { u: User; go: (p: Page) => void; logout: () => void; checks: string[] }) {
  const rows: [string, string, Page][] = [['dumb', 'Meus treinos', 'train'], ['check', `Registrar meu Check-in (${checks.length} no total)`, 'check'], ['pin', 'Academias próximas', 'gyms'], ['cog', 'Configurações', 'settings']]
  return (
    <div>
      <Title>Perfil</Title>
      <div className="mb-5 flex flex-col items-center"><span className="flex h-24 w-24 items-center justify-center rounded-full bg-[#7fb3d5] text-3xl font-bold text-bg">{u.name[0]?.toUpperCase()}</span>
        <p className="mt-2 font-semibold">{u.name}</p><p className="text-xs text-mute">{u.email}</p></div>
      <button onClick={() => go('chat')} className="mb-2 flex w-full items-center gap-3 rounded-lg border border-line bg-surface p-3 text-left"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-ink text-bg text-xs font-bold">BT</span><span className="flex-1 text-xs"><b className="block text-sm">Suporte</b><span className="text-mute">Dúvidas sobre o aplicativo</span></span><Ic n="right" s={16} /></button>
      <div className="space-y-2">{rows.map(([i, l, p]) => <button key={l} onClick={() => go(p)} className="flex h-12 w-full items-center gap-3 rounded-lg border border-line bg-surface px-3 text-left text-xs"><Ic n={i} s={16} /><span className="flex-1">{l}</span><Ic n="right" s={16} /></button>)}</div>
      <button onClick={logout} className="mt-4 h-11 w-full rounded-md border border-bad text-sm text-bad">Sair da conta</button>
    </div>
  )
}
const FAQ: [RegExp, string][] = [
  [/check|frequ/i, 'Para o check-in, abra a aba Check-in e toque em "Fazer check-in de hoje". Concluir um treino também registra o dia.'],
  [/treino|exerc/i, 'Em Treinos você cria treinos, adiciona exercícios por grupo muscular e edita séries, repetições, carga e descanso.'],
  [/caloria|refei|nutri|aliment/i, 'Em Nutrição, escolha o dia e toque em "Registrar refeição". Os totais são somados automaticamente.'],
  [/peso|gordura|evolu/i, 'Em Evolução, registre peso e % de gordura. Os gráficos usam seus registros.'],
  [/senha|conta|exclu|dados|lgpd/i, 'Seus dados ficam neste aparelho. Em Configurações você pode apagar todos os dados e a conta.'],
]
function Chat({ back }: { back: () => void }) {
  const [msgs, setMsgs] = useState<{ me: boolean; t: string }[]>([{ me: false, t: 'Olá! Sou o assistente de ajuda do Beyond Training. Respondo dúvidas de uso do app por respostas pré-definidas (não é IA, e não dou orientação médica ou nutricional).' }])
  const [t, setT] = useState('')
  const send = (e: React.FormEvent) => {
    e.preventDefault(); if (!t.trim()) return
    const r = FAQ.find(([re]) => re.test(t))?.[1] ?? 'Não encontrei essa dúvida. Tente perguntar sobre treino, check-in, nutrição, evolução ou conta. Para saúde, procure um profissional.'
    setMsgs([...msgs, { me: true, t }, { me: false, t: r }]); setT('')
  }
  return (
    <div className="flex h-full flex-col">
      <Title back={back}>Suporte</Title>
      <div className="flex-1 space-y-2 overflow-y-auto" aria-live="polite">
        {msgs.map((m, i) => <div key={i} className={`max-w-[85%] rounded-xl px-3 py-2 text-xs ${m.me ? 'ml-auto bg-accent' : 'bg-surface2'}`}>{m.t}</div>)}
      </div>
      <form onSubmit={send} className="mt-3 flex gap-2"><Field placeholder="Digite sua dúvida" aria-label="Mensagem" value={t} onChange={(e) => setT(e.target.value)} /><Btn type="submit" aria-label="Enviar" className="w-11 px-0"><Ic n="send" s={16} /></Btn></form>
    </div>
  )
}
function Settings({ back, logout, wipe, cfg, setCfg }: { back: () => void; logout: () => void; wipe: () => void; cfg: { notif: boolean; remind: boolean; unit: string }; setCfg: (c: { notif: boolean; remind: boolean; unit: string }) => void }) {
  const Tg = ({ k, l }: { k: 'notif' | 'remind'; l: string }) => (
    <div className="flex h-12 items-center justify-between rounded-lg border border-line bg-surface px-3 text-xs">{l}
      <button role="switch" aria-checked={cfg[k]} aria-label={l} onClick={() => setCfg({ ...cfg, [k]: !cfg[k] })} className={`h-6 w-11 rounded-full p-0.5 ${cfg[k] ? 'bg-accent' : 'bg-line'}`}><span className={`block h-5 w-5 rounded-full bg-ink transition-transform ${cfg[k] ? 'translate-x-5' : ''}`} /></button></div>
  )
  return (
    <div className="space-y-2">
      <Title back={back}>Configurações</Title>
      <p className="text-xs font-semibold">Aplicativo</p>
      <div className="flex h-12 items-center justify-between rounded-lg border border-line bg-surface px-3 text-xs">Unidade de medida
        <select aria-label="Unidade" value={cfg.unit} onChange={(e) => setCfg({ ...cfg, unit: e.target.value })} className="rounded bg-surface2 px-2 py-1"><option value="kg">kg</option></select></div>
      <p className="pt-3 text-xs font-semibold">Notificações</p>
      <Tg k="notif" l="Notificações" /><Tg k="remind" l="Lembretes de treino (preferência salva; envio ainda não implementado)" />
      <p className="pt-3 text-xs font-semibold">Conta e privacidade</p>
      <button onClick={logout} className="h-11 w-full rounded-md border border-bad text-xs text-bad">Sair da conta</button>
      <button onClick={() => confirm('Apagar todos os seus dados e a conta neste aparelho?') && wipe()} className="h-11 w-full rounded-md border border-bad bg-bad/10 text-xs text-bad">Excluir conta e dados</button>
    </div>
  )
}

/* ---------- App ---------- */
export default function App() {
  const [users, setUsers] = useStore<User[]>('users', [])
  const [session, setSession] = useStore<string | null>('session', null)
  const user = users.find((u) => u.email === session)
  const [page, setPage] = useState<Page>('home')
  const today = iso()
  // dados isolados por usuário
  const k = session ?? 'anon'
  const [meals, setMeals] = useStore<Meal[]>(`meals:${k}`, [])
  const [checks, setChecks] = useStore<string[]>(`checks:${k}`, [])
  const [recs, setRecs] = useStore<Rec[]>(`recs:${k}`, [])
  const [mine, setMine] = useStore<Workout[]>(`mine:${k}`, [])
  const [cfg, setCfg] = useStore(`cfg:${k}`, { notif: true, remind: false, unit: 'kg' })

  if (!user) return <Shell><Auth users={users} setUsers={setUsers} login={(e) => { setSession(e); setPage('home') }} /></Shell>
  const logout = () => { setSession(null); setPage('home') }
  const wipe = () => {
    ['meals', 'checks', 'recs', 'mine', 'cfg'].forEach((x) => localStorage.removeItem(`bt:${x}:${k}`))
    setUsers(users.filter((u) => u.email !== k)); setSession(null); setPage('home')
  }
  const addCheck = () => !checks.includes(today) && setChecks([...checks, today])
  const nav: [Page, string][] = [['home', 'Home'], ['food', 'Nutrição'], ['prog', 'Evolução'], ['check', 'Check-in'], ['me', 'Perfil']]
  const tabPage = (['home', 'food', 'prog', 'check', 'me'] as Page[]).includes(page)
  return (
    <Shell>
      <main className={`flex-1 overflow-y-auto px-5 pt-8 pb-5 ${page === 'chat' ? 'flex flex-col' : ''}`}>
        {page === 'home' && <Home u={user} go={setPage} checks={checks} today={today} meals={meals} />}
        {page === 'food' && <Food meals={meals} setMeals={setMeals} today={today} />}
        {page === 'prog' && <Prog recs={recs} setRecs={setRecs} />}
        {page === 'check' && <Check checks={checks} setChecks={setChecks} today={today} go={setPage} />}
        {page === 'me' && <Me u={user} go={setPage} logout={logout} checks={checks} />}
        {page === 'train' && <Train mine={mine} setMine={setMine} checkin={addCheck} back={() => setPage('home')} />}
        {page === 'gyms' && <div><Title back={() => setPage('home')}>Academias próximas</Title><div className="space-y-2"><Gyms onCheck={addCheck} /></div><p className="mt-3 text-[10px] text-mute">Lista de demonstração; localização em tempo real ainda não implementada.</p></div>}
        {page === 'chat' && <Chat back={() => setPage('me')} />}
        {page === 'settings' && <Settings back={() => setPage('me')} logout={logout} wipe={wipe} cfg={cfg} setCfg={setCfg} />}
      </main>
      <nav className="flex border-t border-line bg-bg px-2 pb-2">
        {nav.map(([p, l]) => <button key={p} onClick={() => setPage(p)} aria-current={tabPage && page === p ? 'page' : undefined} className={`flex h-14 flex-1 flex-col items-center justify-center gap-1 text-[10px] ${page === p ? 'text-ink' : 'text-mute'}`}><Ic n={p === 'me' ? 'me' : p} />{l}</button>)}
      </nav>
    </Shell>
  )
}
const Shell = ({ children }: { children: ReactNode }) => (
  <div className="flex min-h-screen items-center justify-center bg-[#04070f] sm:p-6">
    <div className="flex h-screen w-full max-w-[400px] flex-col overflow-hidden bg-bg sm:h-[820px] sm:rounded-[32px] sm:border sm:border-line">{children}</div>
  </div>
)
