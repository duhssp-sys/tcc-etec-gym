import type { ReactNode } from 'react'
import { Icon, Toasts } from './ui'
import { useApp, type Page } from '../lib/store'

const NAV: [Page, string, string][] = [
  ['home', 'Visão geral', 'home'], ['train', 'Treinos', 'dumb'], ['food', 'Alimentação', 'food'], ['prog', 'Progresso', 'prog'], ['chat', 'Beyond AI', 'spark'],
]
const Logo = () => (
  <div className="flex items-center gap-2.5">
    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-accent text-accent-ink"><Icon n="logo" s={20} /></span>
    <span className="text-[15px] font-extrabold leading-none tracking-tight">Beyond<br /><span className="text-mute">Training</span></span>
  </div>
)

export function Shell({ children }: { children: ReactNode }) {
  const { page, go, toasts, theme, setTheme } = useApp()
  const light = theme === 'light'
  const toggleTheme = (cls: string) => (
    <button onClick={() => setTheme(light ? 'dark' : 'light')} aria-label={light ? 'Ativar tema escuro' : 'Ativar tema claro'} title={light ? 'Tema escuro' : 'Tema claro'} className={cls}>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden>{light ? <path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z" /> : <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>}</svg>
    </button>
  )
  const item = (k: Page, l: string, i: string, mobile?: boolean) => {
    const on = page === k
    return (
      <button key={k} onClick={() => go(k)} aria-current={on ? 'page' : undefined}
        className={mobile
          ? `flex min-h-14 flex-1 flex-col items-center justify-center gap-1 text-[11px] font-semibold ${on ? 'text-brand' : 'text-mute'}`
          : `flex h-11 w-full items-center gap-3 rounded-xl px-3 text-sm font-semibold ${on ? 'bg-raised text-ink shadow-[inset_0_0_0_1px_var(--color-line)]' : 'text-mute hover:bg-surface hover:text-ink'}`}>
        <Icon n={i} s={mobile ? 22 : 19} className={!mobile && on ? 'text-brand' : ''} />{l}
      </button>
    )
  }
  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[232px_1fr]">
      <aside className="sticky top-0 hidden h-dvh flex-col border-r border-line bg-surface px-4 py-6 lg:flex">
        <div className="mb-8 px-2"><Logo /></div>
        <nav aria-label="Principal" className="flex flex-col gap-1">{NAV.map(([k, l, i]) => item(k, l, i))}</nav>
        <div className="mt-auto space-y-1 border-t border-line pt-4">
          {item('settings', 'Configurações', 'cog')}
          <button onClick={() => setTheme(light ? 'dark' : 'light')} className="flex h-11 w-full items-center gap-3 rounded-xl px-3 text-sm font-semibold text-mute hover:bg-surface hover:text-ink">
            {toggleTheme('pointer-events-none')}{light ? 'Tema escuro' : 'Tema claro'}
          </button>
          <button onClick={() => go('settings')} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left hover:bg-raised">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand/15 text-sm font-extrabold text-brand">AL</span>
            <span className="min-w-0 text-xs"><b className="block truncate text-sm">Alex Lima</b><span className="text-mute">Plano Gratuito</span></span>
          </button>
        </div>
      </aside>
      <div className="min-w-0">
        <div className="flex items-center justify-between border-b border-line bg-surface px-4 py-3 lg:hidden"><Logo />
          <div className="flex items-center gap-1">{toggleTheme('flex h-10 w-10 items-center justify-center rounded-full text-mute hover:bg-raised hover:text-ink')}
            <button onClick={() => go('settings')} aria-label="Perfil e configurações" className="flex h-10 w-10 items-center justify-center rounded-full bg-brand/15 text-sm font-extrabold text-brand">AL</button></div></div>
        <main className="mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-6 lg:px-10 lg:pb-12 lg:pt-10">
          <div key={page} className="rise">{children}</div>
        </main>
      </div>
      <nav aria-label="Principal" className="fixed inset-x-0 bottom-0 z-40 flex border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">{NAV.map(([k, l, i]) => item(k, l === 'Visão geral' ? 'Início' : l, i, true))}</nav>
      <Toasts items={toasts} />
    </div>
  )
}
