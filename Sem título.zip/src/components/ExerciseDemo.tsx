import { Badge, Button, Icon } from './ui'
import { ExerciseAvatar, hasAnimation } from './ExerciseAvatar'
import { EXERCISES } from '../lib/exercises'
import type { Exercise } from '../lib/data'

/** Painel de exercício: demonstração animada (ou estado alternativo), orientações e parâmetros. */
export function ExerciseDemo({ ex, done, onComplete }: { ex: Exercise; done: boolean; onComplete: () => void }) {
  const info = EXERCISES[ex.name]
  const anim = info?.anim && hasAnimation(info.anim) ? info.anim : null
  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-1.5">
        <Badge tone="accent">{ex.group}</Badge>
        {info && <Badge>{info.equip}</Badge>}
        {info?.secondary.map((s) => <Badge key={s}>+ {s}</Badge>)}
      </div>
      <h3 className="mb-3 text-lg font-extrabold">{ex.name}</h3>
      {anim ? <ExerciseAvatar key={ex.name} kind={anim} name={ex.name} /> : (
        <div className="flex aspect-[4/3] flex-col items-center justify-center rounded-xl border border-dashed border-line bg-bg px-6 text-center">
          <Icon n="info" s={26} className="text-mute" />
          <p className="mt-2 text-sm font-bold">Animação ainda não disponível</p>
          <p className="mt-1 text-xs text-mute">Este exercício ainda não possui demonstração. Siga as orientações abaixo; a animação depende de produção de conteúdo.</p>
        </div>
      )}
      <dl className="my-4 grid grid-cols-4 gap-2 text-center">
        {[['Séries', ex.sets], ['Reps', ex.reps], ['Carga', ex.kg ? `${ex.kg} kg` : '—'], ['Descanso', `${ex.rest}s`]].map(([l, v]) => (
          <div key={l} className="rounded-xl bg-raised py-2.5"><dd className="num text-base font-extrabold">{v}</dd><dt className="text-[11px] text-mute">{l}</dt></div>
        ))}
      </dl>
      {info && (<>
        <h4 className="mb-2 text-sm font-bold">Como executar</h4>
        <ol className="space-y-2 text-sm text-mute">{info.steps.map((s, i) => <li key={i} className="flex gap-2.5"><span className="num mt-px flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-raised text-[11px] font-bold text-ink">{i + 1}</span>{s}</li>)}</ol>
        <h4 className="mb-2 mt-4 text-sm font-bold">Erros comuns</h4>
        <ul className="space-y-1.5 text-sm text-mute">{info.errors.map((s) => <li key={s} className="flex gap-2"><Icon n="alert" s={15} className="mt-0.5 text-warn" />{s}</li>)}</ul>
      </>)}
      <p className="mt-4 text-[11px] leading-relaxed text-mute">Demonstração visual estilizada, sem substituir a orientação presencial de um profissional de Educação Física.</p>
      <Button className="mt-4 w-full" variant={done ? 'secondary' : 'primary'} onClick={onComplete}><Icon n="check" s={16} />{done ? 'Exercício concluído (desfazer)' : 'Concluir exercício'}</Button>
    </div>
  )
}
