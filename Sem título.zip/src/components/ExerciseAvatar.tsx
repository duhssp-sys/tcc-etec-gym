import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { Icon } from './ui'

/**
 * Avatar demonstrativo em vista lateral. As posições de cada articulação são calculadas
 * por cinemática direta a partir de ângulos (graus, 0 = para baixo, 90 = para frente, 180 = para cima)
 * e interpoladas entre a posição inicial e a final. Cada exercício tem sua própria definição.
 * É uma representação estilizada para entendimento do movimento, não um modelo anatômico 3D
 * nem substitui a orientação de um profissional.
 */
type Pose = { T: number; A: number; F: number; H: number; S: number }
type Pt = [number, number]
type Pts = { hip: Pt; sh: Pt; head: Pt; el: Pt; hand: Pt; knee: Pt; ankle: Pt; toe: Pt }
type Def = {
  a: Pose; b: Pose
  anchor: { hip: Pt } | { ankle: Pt }
  hi: [keyof Pose | 'torso' | 'upper' | 'fore' | 'thigh' | 'shin', number, number][] // trechos destacados (músculo-alvo)
  scene: (p: Pts, t: number) => ReactNode // equipamento
  label: [string, string] // descrição da fase de execução e do retorno
}
const L = { torso: 50, up: 27, fore: 25, thigh: 37, shin: 37, foot: 11 }
const dir = (deg: number): Pt => [Math.sin((deg * Math.PI) / 180), Math.cos((deg * Math.PI) / 180)]
const add = (p: Pt, d: Pt, l: number): Pt => [p[0] + d[0] * l, p[1] + d[1] * l]

function solve(po: Pose, anchor: Def['anchor']): Pts {
  const tv = dir(po.T), hv = dir(po.H), sv = dir(po.S)
  let hip: Pt
  if ('hip' in anchor) hip = anchor.hip
  else hip = [anchor.ankle[0] - hv[0] * L.thigh - sv[0] * L.shin, anchor.ankle[1] - hv[1] * L.thigh - sv[1] * L.shin]
  // torso aponta de quadril para ombro: ângulo 180 = para cima (y negativo)
  const shoulder: Pt = [hip[0] + tv[0] * L.torso, hip[1] + tv[1] * L.torso]
  const head = add(shoulder, tv, 17)
  const el = add(shoulder, dir(po.A), L.up), hand = add(el, dir(po.F), L.fore)
  const knee = add(hip, hv, L.thigh), ankle = add(knee, sv, L.shin), toe = add(ankle, dir(po.S + 90), L.foot)
  return { hip, sh: shoulder, head, el, hand, knee, ankle, toe }
}
const lerp = (a: Pose, b: Pose, e: number): Pose => ({ T: a.T + (b.T - a.T) * e, A: a.A + (b.A - a.A) * e, F: a.F + (b.F - a.F) * e, H: a.H + (b.H - a.H) * e, S: a.S + (b.S - a.S) * e })

const plate = (c: Pt, r = 10) => <g><circle cx={c[0]} cy={c[1]} r={r} fill="none" stroke="var(--color-mute)" strokeWidth="3" /><circle cx={c[0]} cy={c[1]} r="2.5" fill="var(--color-mute)" /></g>
const db = (c: Pt) => <g><rect x={c[0] - 5} y={c[1] - 5} width="10" height="10" rx="2" fill="var(--color-mute)" /></g>
const eq = { stroke: 'var(--color-mute)', strokeWidth: 3, strokeLinecap: 'round' as const, fill: 'none' }
const FLOOR = 162
const floor = <line x1="10" x2="230" y1={FLOOR} y2={FLOOR} stroke="var(--color-line)" strokeWidth="2" />
const bench = (y: number, x1: number, x2: number) => <path d={`M${x1} ${y} H${x2} M${(x1 + x2) / 2} ${y} V${FLOOR}`} {...eq} />
const std = { T: 180, A: 0, F: 0, H: 0, S: 0 }

const DEFS: Record<string, Def> = {
  supino: {
    anchor: { hip: [165, 118] }, label: ['Empurre a barra para cima', 'Desça a barra com controle'],
    a: { T: -90, A: 180, F: 180, H: 82, S: 4 }, b: { T: -90, A: 35, F: 180, H: 82, S: 4 },
    hi: [['torso', 0.55, 1]],
    scene: (p) => <g>{bench(124, 60, 180)}{plate(p.hand)}</g>,
  },
  agachamento: {
    anchor: { ankle: [108, FLOOR - 4] }, label: ['Desça levando o quadril para trás', 'Suba empurrando o chão'],
    a: { T: 180, A: -30, F: 165, H: 0, S: 0 }, b: { T: 125, A: -30, F: 165, H: 100, S: -30 },
    hi: [['thigh', 0, 1]],
    scene: (p) => <g>{plate([p.sh[0] - 4, p.sh[1] - 2], 11)}</g>,
  },
  rosca: {
    anchor: { ankle: [118, FLOOR - 4] }, label: ['Flexione os cotovelos', 'Desça sem balançar o tronco'],
    a: { ...std, A: 0, F: 0 }, b: { ...std, A: 0, F: 150 },
    hi: [['upper', 0, 1]],
    scene: (p) => <g>{plate(p.hand, 7)}</g>,
  },
  desenvolvimento: {
    anchor: { hip: [112, 118] }, label: ['Empurre os halteres para cima', 'Desça até a altura das orelhas'],
    a: { T: 182, A: 30, F: 180, H: 88, S: 4 }, b: { T: 182, A: 175, F: 180, H: 88, S: 4 },
    hi: [['upper', 0, 1]],
    scene: (p) => <g><path d={`M${p.hip[0] - 14} ${p.hip[1] - 70} V${p.hip[1] + 8} H${p.hip[0] + 12} V${FLOOR}`} {...eq} />{db(p.hand)}</g>,
  },
  puxada: {
    anchor: { hip: [120, 121] }, label: ['Puxe a barra até o peito', 'Retorne os braços com controle'],
    a: { T: 188, A: 170, F: 175, H: 88, S: 4 }, b: { T: 197, A: -20, F: 150, H: 88, S: 4 },
    hi: [['torso', 0.3, 1]],
    scene: (p) => <g><line x1={p.hand[0]} y1="14" x2={p.hand[0]} y2={p.hand[1]} stroke="var(--color-mute)" strokeWidth="1.5" strokeDasharray="3 3" /><circle cx={p.hand[0]} cy="14" r="5" {...eq} /><line x1={p.hand[0] - 14} x2={p.hand[0] + 14} y1={p.hand[1]} y2={p.hand[1]} {...eq} /><path d={`M${p.hip[0] - 18} ${p.hip[1] + 9} H${p.hip[0] + 6} V${FLOOR}`} {...eq} /></g>,
  },
  remada: {
    anchor: { hip: [95, 142] }, label: ['Puxe em direção ao abdômen', 'Estenda os braços com controle'],
    a: { T: 160, A: 95, F: 95, H: 88, S: 72 }, b: { T: 185, A: -5, F: 85, H: 88, S: 72 },
    hi: [['torso', 0.3, 1]],
    scene: (p) => <g><path d={`M${p.hand[0]} ${p.hand[1]} L${p.hip[0] + 125} 138`} stroke="var(--color-mute)" strokeWidth="1.5" strokeDasharray="3 3" /><rect x={p.hip[0] + 118} y="122" width="14" height="40" rx="3" fill="none" stroke="var(--color-mute)" strokeWidth="3" /><path d={`M${p.hip[0] - 14} ${p.hip[1] + 10} H${p.hip[0] + 10} V${FLOOR}`} {...eq} />{db(p.hand)}</g>,
  },
  extensora: {
    anchor: { hip: [100, 120] }, label: ['Estenda os joelhos', 'Retorne com controle'],
    a: { T: 190, A: 20, F: 60, H: 90, S: 0 }, b: { T: 190, A: 20, F: 60, H: 90, S: 85 },
    hi: [['thigh', 0, 1]],
    scene: (p) => <g><path d={`M${p.hip[0] - 14} ${p.hip[1] - 60} V${p.hip[1] + 8} H${p.hip[0] + 30} V${FLOOR}`} {...eq} /><circle cx={p.ankle[0] + 2} cy={p.ankle[1] - 6} r="5" fill="var(--color-mute)" /></g>,
  },
  triceps: {
    anchor: { ankle: [112, FLOOR - 4] }, label: ['Estenda os cotovelos', 'Retorne até 90° com controle'],
    a: { T: 178, A: 8, F: 95, H: 0, S: 0 }, b: { T: 178, A: 8, F: 2, H: 0, S: 0 },
    hi: [['upper', 0, 1]],
    scene: (p) => <g><line x1="132" y1="12" x2={p.hand[0]} y2={p.hand[1]} stroke="var(--color-mute)" strokeWidth="1.5" strokeDasharray="3 3" /><circle cx="132" cy="12" r="5" {...eq} /><rect x={p.hand[0] - 4} y={p.hand[1] - 3} width="10" height="7" rx="3" fill="var(--color-mute)" /></g>,
  },
  stiff: {
    anchor: { ankle: [110, FLOOR - 4] }, label: ['Leve o quadril para trás', 'Retorne estendendo o quadril'],
    a: { T: 178, A: 4, F: 4, H: 0, S: 0 }, b: { T: 105, A: 2, F: 2, H: 20, S: -6 },
    hi: [['thigh', 0, 1]],
    scene: (p) => <g>{plate(p.hand, 9)}</g>,
  },
  pelvica: {
    anchor: { ankle: [160, FLOOR - 4] }, label: ['Eleve o quadril', 'Desça com controle'],
    a: { T: -90, A: 90, F: 90, H: 144, S: 10 }, b: { T: -63, A: 78, F: 80, H: 100, S: 2 },
    hi: [['thigh', 0, 1]],
    scene: () => <g />,
  },
  prancha: {
    anchor: { hip: [135, 146] }, label: ['Mantenha o corpo alinhado', 'Respire de forma contínua'],
    a: { T: -102, A: 0, F: -90, H: 80, S: 82 }, b: { T: -99, A: 0, F: -90, H: 81, S: 82 },
    hi: [['torso', 0, 1]],
    scene: () => <g />,
  },
}

export const hasAnimation = (k?: string) => !!k && k in DEFS

export function ExerciseAvatar({ kind, name, onReps }: { kind: string; name: string; onReps?: (n: number) => void }) {
  const def = DEFS[kind]
  const reduce = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  const [playing, setPlaying] = useState(!reduce)
  const [speed, setSpeed] = useState(1)
  const [t, setT] = useState(0)
  const [reps, setReps] = useState(0)
  const last = useRef(0)
  useEffect(() => {
    if (!playing) return
    let raf = 0
    const loop = (now: number) => {
      const dt = last.current ? (now - last.current) / 1000 : 0
      last.current = now
      setT((x) => { const n = x + (dt * speed) / 3.2; if (n >= 1) { setReps((r) => r + 1); return n - 1 } return n })
      raf = requestAnimationFrame(loop)
    }
    last.current = 0
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [playing, speed])
  useEffect(() => { onReps?.(reps) }, [reps, onReps])
  const e = (1 - Math.cos(2 * Math.PI * t)) / 2
  const pose = useMemo(() => lerp(def.a, def.b, e), [def, e])
  const p = solve(pose, def.anchor)
  const phase = t < 0.1 || t > 0.9 ? 'Posição inicial' : t < 0.5 ? def.label[0] : t < 0.6 ? 'Posição final' : def.label[1]
  const limb = (a: Pt, b: Pt, w: number, color = 'var(--color-ink)', o = 0.8) => <line x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={color} strokeOpacity={o} strokeWidth={w} strokeLinecap="round" />
  const seg = { torso: [p.hip, p.sh], upper: [p.sh, p.el], fore: [p.el, p.hand], thigh: [p.hip, p.knee], shin: [p.knee, p.ankle] } as Record<string, [Pt, Pt]>
  return (
    <div>
      <div className="relative overflow-hidden rounded-xl border border-control bg-bg">
        <svg viewBox="0 0 240 180" className="block w-full" role="img" aria-label={`Demonstração animada de ${name}. Fase atual: ${phase}.`}>
          {floor}
          {def.scene(p, t)}
          {/* destaque do músculo-alvo sob a figura */}
          {def.hi.map(([k, f0, f1], i) => { const [a, b] = seg[k as string]; const pa: Pt = [a[0] + (b[0] - a[0]) * f0, a[1] + (b[1] - a[1]) * f0], pb: Pt = [a[0] + (b[0] - a[0]) * f1, a[1] + (b[1] - a[1]) * f1]; return <line key={i} x1={pa[0]} y1={pa[1]} x2={pb[0]} y2={pb[1]} stroke="var(--color-brand)" strokeWidth="19" strokeLinecap="round" strokeOpacity="0.45" /> })}
          {limb(p.hip, p.knee, 11)}{limb(p.knee, p.ankle, 9)}{limb(p.ankle, p.toe, 6)}
          {limb(p.hip, p.sh, 17, 'var(--color-ink)', 0.9)}
          {limb(p.sh, p.el, 8)}{limb(p.el, p.hand, 7)}
          <circle cx={p.head[0]} cy={p.head[1]} r="10" fill="var(--color-ink)" fillOpacity="0.9" />
          {[p.sh, p.el, p.hip, p.knee].map((j, i) => <circle key={i} cx={j[0]} cy={j[1]} r="2.4" fill="var(--color-bg)" />)}
        </svg>
        <span className="absolute left-3 top-3 rounded-full bg-surface/90 px-2.5 py-1 text-[11px] font-bold">{phase}</span>
        <span className="num absolute right-3 top-3 rounded-full bg-surface/90 px-2.5 py-1 text-[11px] font-bold">{reps} rep.</span>
      </div>
      <div className="mt-3 flex items-center gap-3">
        <button onClick={() => setPlaying(!playing)} aria-label={playing ? 'Pausar animação' : 'Reproduzir animação'} className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-ink hover:brightness-110">
          {playing ? <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden><rect x="6" y="5" width="4" height="14" rx="1" /><rect x="14" y="5" width="4" height="14" rx="1" /></svg> : <Icon n="play" s={18} />}
        </button>
        <label className="flex-1 text-[11px] font-semibold text-mute">Posição do movimento
          <input type="range" min="0" max="50" value={Math.round(Math.min(t, 1 - t) * 100)} onChange={(ev) => { setPlaying(false); setT(+ev.target.value / 100) }} className="mt-1 block h-6 w-full accent-[var(--color-accent)]" />
        </label>
        <div role="group" aria-label="Velocidade" className="flex rounded-xl border border-line p-0.5">
          {[0.5, 1, 1.5].map((s) => <button key={s} aria-pressed={speed === s} onClick={() => setSpeed(s)} className={`num h-10 min-w-11 rounded-lg px-2 text-xs font-bold ${speed === s ? 'bg-raised text-ink' : 'text-mute'}`}>{s}x</button>)}
        </div>
      </div>
    </div>
  )
}
