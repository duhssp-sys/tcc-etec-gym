import type { Level } from '../lib/store'

/** Silhueta estilizada (frente e costas) com regiões musculares selecionáveis. */
type Region = { id: string; shape: 'e' | 'p'; v: 'f' | 'b'; a: (number | string)[]; mirror?: boolean }
const R: Region[] = [
  // frente
  { id: 'Ombros', v: 'f', shape: 'e', a: [37, 54, 8, 8], mirror: true },
  { id: 'Peito', v: 'f', shape: 'p', a: ['M59 56 L59 77 Q47 81 40 72 Q39 61 47 57 Z'], mirror: true },
  { id: 'Bíceps', v: 'f', shape: 'e', a: [31, 77, 5.5, 13], mirror: true },
  { id: 'Abdômen', v: 'f', shape: 'p', a: ['M52 82 L59 82 L59 114 Q53 114 51 107 Z'], mirror: true },
  { id: 'Quadríceps', v: 'f', shape: 'e', a: [50, 146, 9.5, 27], mirror: true },
  { id: 'Panturrilhas', v: 'f', shape: 'e', a: [48, 203, 6.5, 19], mirror: true },
  // costas
  { id: 'Ombros', v: 'b', shape: 'e', a: [37, 54, 8, 8], mirror: true },
  { id: 'Costas', v: 'b', shape: 'p', a: ['M59 52 L59 108 Q48 108 44 96 Q39 76 46 56 Z'], mirror: true },
  { id: 'Tríceps', v: 'b', shape: 'e', a: [31, 77, 5.5, 13], mirror: true },
  { id: 'Glúteos', v: 'b', shape: 'e', a: [51, 124, 10, 10], mirror: true },
  { id: 'Posterior de coxa', v: 'b', shape: 'e', a: [50, 156, 8.5, 22], mirror: true },
  { id: 'Panturrilhas', v: 'b', shape: 'e', a: [48, 203, 6.5, 19], mirror: true },
]
const FILL: Record<Level | 'none', [string, number]> = { alta: ['var(--color-brand)', 1], media: ['var(--color-brand)', 0.6], baixa: ['var(--color-brand)', 0.3], none: ['var(--color-raised)', 1] }
const LABEL: Record<Level, string> = { alta: 'prioridade alta', media: 'prioridade média', baixa: 'prioridade baixa' }

export function BodyMap({ view, levels, onPick, hover, setHover }: { view: 'f' | 'b'; levels: Record<string, Level | undefined>; onPick: (id: string) => void; hover: string | null; setHover: (id: string | null) => void }) {
  const shape = (r: Region, mir: boolean) => {
    const common = { transform: mir ? 'translate(120 0) scale(-1 1)' : undefined }
    return r.shape === 'e' ? <ellipse key={String(mir)} cx={r.a[0] as number} cy={r.a[1] as number} rx={r.a[2] as number} ry={r.a[3] as number} {...common} /> : <path key={String(mir)} d={r.a[0] as string} {...common} />
  }
  const sil = { fill: 'var(--color-surface)', stroke: 'var(--color-line)', strokeWidth: 1.5 }
  return (
    <svg viewBox="0 0 120 235" className="mx-auto block h-full max-h-[420px] w-full" role="group" aria-label={view === 'f' ? 'Corpo, vista frontal' : 'Corpo, vista posterior'}>
      <circle cx="60" cy="20" r="11" {...sil} /><rect x="55" y="30" width="10" height="9" {...sil} />
      <path d="M36 44 Q60 38 84 44 L80 112 Q60 120 40 112 Z" {...sil} />
      {[0, 1].map((m) => <g key={m} transform={m ? 'translate(120 0) scale(-1 1)' : undefined}>
        <ellipse cx="30" cy="77" rx="6.5" ry="15" {...sil} /><ellipse cx="26" cy="108" rx="5" ry="16" {...sil} />
        <ellipse cx="50" cy="146" rx="11" ry="29" {...sil} /><ellipse cx="48" cy="203" rx="7.5" ry="21" {...sil} />
      </g>)}
      {R.filter((r) => r.v === view).map((r) => {
        const lv = levels[r.id], [fill, op] = FILL[lv ?? 'none'], on = hover === r.id
        return (
          <g key={r.id} role="button" tabIndex={0} aria-label={`${r.id}: ${lv ? LABEL[lv] : 'não priorizado'}`} aria-pressed={!!lv}
            onClick={() => onPick(r.id)} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onPick(r.id))}
            onMouseEnter={() => setHover(r.id)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(r.id)} onBlur={() => setHover(null)}
            fill={fill} fillOpacity={op} stroke={on ? 'var(--color-ink)' : 'var(--color-line)'} strokeWidth={on ? 1.6 : 1} className="cursor-pointer outline-none">
            {shape(r, false)}{r.mirror && shape(r, true)}
          </g>
        )
      })}
    </svg>
  )
}
