import { useEffect, useRef, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from 'react'

const P: Record<string, string> = {
  home: 'M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z',
  dumb: 'M6 7v10M18 7v10M3 10v4M21 10v4M6 12h12',
  food: 'M12 7c-3-2-7 0-7 5 0 4 3 9 7 7 4 2 7-3 7-7 0-5-4-7-7-5zM12 7c0-2 1-3 3-4',
  prog: 'M4 19V5M4 19h16M8 15l4-5 3 3 5-7',
  chat: 'M21 12a8 8 0 01-11.6 7.1L4 20l1-4.6A8 8 0 1121 12z',
  cog: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1-2-1-1-2h-4l-1 2-2 1-2-1-2 4 2 1v2l-2 1 2 4 2-1 2 1 1 2h4l1-2 2-1 2 1 2-4-2-1z',
  check: 'M5 12l5 5 9-10',
  plus: 'M12 5v14M5 12h14', minus: 'M5 12h14',
  trash: 'M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13',
  edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  back: 'M15 5l-7 7 7 7', right: 'M9 5l7 7-7 7', left: 'M15 5l-7 7 7 7',
  send: 'M4 12l16-8-6 16-3-6z',
  close: 'M6 6l12 12M18 6L6 18',
  drop: 'M12 3s6 6.5 6 11a6 6 0 01-12 0c0-4.5 6-11 6-11z',
  clock: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2',
  play: 'M8 5l11 7-11 7z', bell: 'M6 16V11a6 6 0 0112 0v5l2 2H4zM10 21h4',
  flame: 'M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z',
  info: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v5M12 8v.01',
  alert: 'M12 4l9 16H3zM12 10v4M12 17v.01',
  spark: 'M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2 2M16 16l2 2M18 6l-2 2M8 16l-2 2',
  user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  logo: 'M4 17l5-5 3 3 8-9M15 6h5v5',
}
export const Icon = ({ n, s = 20, className = '' }: { n: string; s?: number; className?: string }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden className={`shrink-0 ${className}`}><path d={P[n]} /></svg>
)

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; loading?: boolean; size?: 'md' | 'sm' }
export function Button({ variant = 'primary', loading, size = 'md', className = '', children, disabled, ...p }: BtnProps) {
  const v = {
    primary: 'bg-accent text-accent-ink hover:brightness-110 active:scale-[.98] font-bold',
    secondary: 'border border-line bg-raised text-ink hover:border-mute font-semibold',
    ghost: 'text-mute hover:bg-raised hover:text-ink font-semibold',
    danger: 'border border-bad/40 text-bad hover:bg-bad/10 font-semibold',
  }[variant]
  return (
    <button {...p} disabled={disabled || loading} aria-busy={loading} className={`inline-flex items-center justify-center gap-2 rounded-xl text-sm disabled:cursor-not-allowed disabled:opacity-40 ${size === 'md' ? 'h-11 px-5' : 'h-9 px-3.5'} ${v} ${className}`}>
      {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden />}
      {children}
    </button>
  )
}
export const IconButton = ({ label, n, className = '', ...p }: { label: string; n: string } & ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button {...p} aria-label={label} title={label} className={`flex h-10 w-10 items-center justify-center rounded-xl text-mute hover:bg-raised hover:text-ink disabled:opacity-40 ${className}`}><Icon n={n} s={18} /></button>
)

export const Card = ({ children, className = '', raised }: { children: ReactNode; className?: string; raised?: boolean }) => (
  <section className={`rounded-card border border-line p-5 ${raised ? 'bg-raised' : 'bg-surface'} ${className}`}>{children}</section>
)
export const SectionTitle = ({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) => (
  <div className="mb-4 flex items-start justify-between gap-3">
    <div><h2 className="text-base font-bold">{title}</h2>{hint && <p className="mt-0.5 text-xs text-mute">{hint}</p>}</div>{action}
  </div>
)
export const PageHeader = ({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) => (
  <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
    <div><h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{title}</h1>{desc && <p className="mt-1 max-w-xl text-sm text-mute">{desc}</p>}</div>{action}
  </header>
)
export const Badge = ({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'neutral' | 'ok' | 'warn' | 'info' | 'accent' }) => {
  const t = { neutral: 'bg-raised text-mute', ok: 'bg-ok/10 text-ok', warn: 'bg-warn/10 text-warn', info: 'bg-info/10 text-info', accent: 'bg-brand/10 text-brand' }[tone]
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ${t}`}>{children}</span>
}
export const DemoTag = ({ children = 'Dados demonstrativos' }: { children?: string }) => <Badge tone="warn"><Icon n="info" s={12} />{children}</Badge>

export const Progress = ({ value, max = 100, label, tone = 'accent' }: { value: number; max?: number; label: string; tone?: 'accent' | 'info' }) => (
  <div role="progressbar" aria-label={label} aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={max} className="h-2 overflow-hidden rounded-full bg-raised">
    <div className={`h-full rounded-full ${tone === 'info' ? 'bg-info' : 'bg-brand'}`} style={{ width: `${Math.min(100, (value / max) * 100)}%`, transition: 'width .4s' }} />
  </div>
)
export function Ring({ value, max, size = 120, label, children }: { value: number; max: number; size?: number; label: string; children?: ReactNode }) {
  const r = 46, c = 2 * Math.PI * r
  return (
    <div className="relative" style={{ width: size, height: size }} role="img" aria-label={label}>
      <svg viewBox="0 0 110 110" className="-rotate-90"><circle cx="55" cy="55" r={r} fill="none" stroke="var(--color-raised)" strokeWidth="9" />
        <circle cx="55" cy="55" r={r} fill="none" stroke="var(--color-brand)" strokeWidth="9" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - Math.min(1, value / max))} style={{ transition: 'stroke-dashoffset .5s' }} /></svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">{children}</div>
    </div>
  )
}
export function Segmented<T extends string>({ value, onChange, options, label }: { value: T; onChange: (v: T) => void; options: [T, string][]; label: string }) {
  return (
    <div role="tablist" aria-label={label} className="inline-flex rounded-xl border border-line bg-surface p-1">
      {options.map(([k, l]) => (
        <button key={k} role="tab" aria-selected={value === k} onClick={() => onChange(k)} className={`h-9 rounded-lg px-4 text-sm font-semibold ${value === k ? 'bg-raised text-ink shadow-[inset_0_0_0_1px_var(--color-line)]' : 'text-mute hover:text-ink'}`}>{l}</button>
      ))}
    </div>
  )
}
export const Field = ({ label, hint, className = '', ...p }: { label: string; hint?: string } & InputHTMLAttributes<HTMLInputElement>) => (
  <label className={`block ${className}`}>
    <span className="mb-1.5 block text-xs font-semibold text-mute">{label}</span>
    <input {...p} className="h-11 w-full rounded-xl border border-control bg-bg px-3.5 text-sm text-ink placeholder:text-mute/60 hover:border-mute focus:border-brand focus:outline-none disabled:opacity-50" />
    {hint && <span className="mt-1 block text-[11px] text-mute">{hint}</span>}
  </label>
)
export const Select = ({ label, children, className = '', ...p }: { label: string } & React.SelectHTMLAttributes<HTMLSelectElement>) => (
  <label className={`block ${className}`}>
    <span className="mb-1.5 block text-xs font-semibold text-mute">{label}</span>
    <select {...p} className="h-11 w-full rounded-xl border border-control bg-bg px-3 text-sm text-ink hover:border-mute focus:border-brand focus:outline-none">{children}</select>
  </label>
)
export const EmptyState = ({ icon, title, desc, action }: { icon: string; title: string; desc: string; action?: ReactNode }) => (
  <div className="flex flex-col items-center rounded-card border border-dashed border-line px-6 py-10 text-center">
    <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-raised text-mute"><Icon n={icon} s={22} /></span>
    <p className="font-bold">{title}</p><p className="mt-1 max-w-sm text-sm text-mute">{desc}</p>{action && <div className="mt-4">{action}</div>}
  </div>
)
export const Skeleton = ({ className = '' }: { className?: string }) => <div aria-hidden className={`animate-pulse rounded-lg bg-raised ${className}`} />

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    ref.current?.querySelector<HTMLElement>('input,select,button')?.focus()
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', k)
    return () => { window.removeEventListener('keydown', k); prev?.focus() }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className="rise max-h-[92dvh] w-full overflow-y-auto rounded-t-2xl border border-line bg-surface p-5 sm:max-w-lg sm:rounded-2xl">
        <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold">{title}</h2><IconButton label="Fechar" n="close" onClick={onClose} /></div>
        {children}
      </div>
    </div>
  )
}
export function Toasts({ items }: { items: { id: number; msg: string; tone: string }[] }) {
  return (
    <div role="status" aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-24 z-[60] flex flex-col items-center gap-2 px-4 lg:bottom-6">
      {items.map((t) => (
        <div key={t.id} className="rise pointer-events-auto flex items-center gap-2 rounded-xl border border-line bg-raised px-4 py-3 text-sm font-semibold shadow-lg">
          <Icon n={t.tone === 'bad' ? 'alert' : 'check'} s={16} className={t.tone === 'bad' ? 'text-bad' : 'text-ok'} />{t.msg}
        </div>
      ))}
    </div>
  )
}
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} className={`relative h-7 w-12 shrink-0 rounded-full border ${checked ? 'border-brand bg-accent' : 'border-line bg-raised'}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full ${checked ? 'left-6 bg-accent-ink' : 'left-0.5 bg-mute'}`} style={{ transition: 'left .15s' }} />
    </button>
  )
}
