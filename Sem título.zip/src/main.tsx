import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

try { if (localStorage.getItem('bt:theme') === 'light') document.documentElement.classList.add('light') } catch { /* sem armazenamento */ }

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
