import { useState } from 'react'
import { useApp } from '../lib/store'
import { Badge, Button, Card, DemoTag, Field, PageHeader, SectionTitle, Segmented, Select, Toggle, Modal } from '../components/ui'

export function Settings() {
  const { toast, theme, setTheme, go, priorities } = useApp()
  const [p, setP] = useState({ name: 'Alex Lima', email: 'alex@exemplo.com', goal: 'Hipertrofia', level: 'Intermediário', days: '4', height: '175', weight: '74' })
  const [n, setN] = useState({ workout: true, meals: true, water: false })
  const [del, setDel] = useState(false)
  const set = (k: keyof typeof p) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setP({ ...p, [k]: e.target.value })
  return (
    <div className="max-w-3xl">
      <PageHeader title="Perfil e configurações" desc="Seus dados e preferências usados na experiência." action={<DemoTag>Não salvo permanentemente</DemoTag>} />
      <form onSubmit={(e) => { e.preventDefault(); toast('Alterações aplicadas nesta sessão') }} className="space-y-4">
        <Card>
          <SectionTitle title="Perfil" />
          <div className="mb-5 flex items-center gap-4"><span className="flex h-16 w-16 items-center justify-center rounded-full bg-brand/15 text-xl font-extrabold text-brand">{p.name.split(' ').map((s) => s[0]).slice(0, 2).join('')}</span><div><p className="font-bold">{p.name}</p><p className="text-sm text-mute">{p.email}</p></div></div>
          <div className="grid gap-4 sm:grid-cols-2"><Field label="Nome" value={p.name} onChange={set('name')} required /><Field label="E-mail" type="email" value={p.email} onChange={set('email')} required /></div>
        </Card>
        <Card>
          <SectionTitle title="Objetivos e dados gerais" hint="Usados para sugerir metas de exemplo na interface." />
          <div className="grid gap-4 sm:grid-cols-2">
            <Select label="Objetivo principal" value={p.goal} onChange={set('goal')}>{['Hipertrofia', 'Emagrecimento', 'Condicionamento', 'Manutenção'].map((o) => <option key={o}>{o}</option>)}</Select>
            <Select label="Nível de experiência" value={p.level} onChange={set('level')}>{['Iniciante', 'Intermediário', 'Avançado'].map((o) => <option key={o}>{o}</option>)}</Select>
            <Select label="Treinos por semana" value={p.days} onChange={set('days')}>{[2, 3, 4, 5, 6].map((o) => <option key={o}>{o}</option>)}</Select>
            <div className="grid grid-cols-2 gap-3"><Field label="Altura (cm)" type="number" value={p.height} onChange={set('height')} /><Field label="Peso (kg)" type="number" value={p.weight} onChange={set('weight')} /></div>
          </div>
        </Card>
        <Card>
          <SectionTitle title="Aparência" hint="A escolha é lembrada neste navegador." />
          <Segmented label="Tema" value={theme} onChange={setTheme} options={[['dark', 'Escuro'], ['light', 'Claro']]} />
        </Card>
        <Card>
          <SectionTitle title="Prioridades musculares" hint="Usadas como referência para organizar sua rotina." action={<Button type="button" size="sm" variant="secondary" onClick={() => go('train', 'priorities')}>Editar</Button>} />
          <div className="flex flex-wrap gap-1.5">{priorities.length ? priorities.map((p) => <Badge key={p.id} tone={p.level === 'alta' ? 'accent' : 'neutral'}>{p.id} · {p.level === 'media' ? 'média' : p.level}</Badge>) : <span className="text-sm text-mute">Nenhuma definida.</span>}</div>
        </Card>
        <Card>
          <SectionTitle title="Notificações" />
          <ul className="divide-y divide-line">{([['workout', 'Lembrete de treino', 'Aviso no horário dos treinos planejados'], ['meals', 'Registro de refeições', 'Lembrete quando uma refeição estiver pendente'], ['water', 'Hidratação', 'Lembretes ao longo do dia']] as const).map(([k, l, d]) => (
            <li key={k} className="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0"><div><p className="text-sm font-bold">{l}</p><p className="text-xs text-mute">{d}</p></div><Toggle label={l} checked={n[k]} onChange={(v) => setN({ ...n, [k]: v })} /></li>))}</ul>
          <p className="mt-3 text-[11px] text-mute">Notificações reais dependem de implementação futura.</p>
        </Card>
        <Card>
          <SectionTitle title="Plano" action={<Badge tone="neutral">Gratuito</Badge>} />
          <p className="text-sm text-mute">O plano Premium previsto inclui acompanhamento profissional de nutrição. Ainda não disponível neste protótipo.</p>
          <Button variant="secondary" size="sm" className="mt-4" type="button" onClick={() => toast('Planos pagos ainda não estão disponíveis', 'info')}>Conhecer o Premium</Button>
        </Card>
        <Card>
          <SectionTitle title="Conta" />
          <div className="flex flex-wrap gap-3"><Button variant="secondary" type="button" onClick={() => toast('Alteração de senha exige o servidor (não implementado)', 'info')}>Alterar senha</Button><Button variant="secondary" type="button" onClick={() => toast('Sessão encerrada (simulação)', 'info')}>Sair</Button><Button variant="danger" type="button" onClick={() => setDel(true)}>Excluir conta</Button></div>
        </Card>
        <div className="sticky bottom-20 flex justify-end lg:bottom-4"><Button type="submit" className="shadow-lg">Salvar alterações</Button></div>
      </form>
      <Modal open={del} onClose={() => setDel(false)} title="Excluir conta?">
        <p className="text-sm text-mute">Em um sistema real, esta ação apagaria seus dados definitivamente. Aqui é apenas uma demonstração do fluxo de confirmação.</p>
        <div className="mt-5 flex justify-end gap-2"><Button variant="ghost" onClick={() => setDel(false)}>Cancelar</Button><Button variant="danger" onClick={() => { setDel(false); toast('Exclusão simulada. Nada foi removido.', 'info') }}>Confirmar exclusão</Button></div>
      </Modal>
    </div>
  )
}
