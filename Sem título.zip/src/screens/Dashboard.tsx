import { useApp } from '../lib/store'
import { Badge, Button, Card, DemoTag, Icon, Progress, Ring, SectionTitle } from '../components/ui'
import { GOALS, WEEK } from '../lib/data'

export function Dashboard() {
  const { go, openWorkout, workouts, meals, water, addWater, toast, priorities } = useApp()
  const now = new Date()
  const date = now.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })
  const hour = now.getHours()
  const greet = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite'
  const next = workouts.find((w) => w.status === 'andamento') ?? workouts.find((w) => w.status === 'planejado')!
  const tot = meals.reduce((a, m) => ({ k: a.k + m.kcal, p: a.p + m.p, c: a.c + m.c, f: a.f + m.f }), { k: 0, p: 0, c: 0, f: 0 })
  const done = WEEK.filter((d) => d.done).length
  const totalMin = WEEK.reduce((a, d) => a + d.min, 0)
  const max = Math.max(...WEEK.map((d) => d.min))
  const missing = ['Lanche', 'Jantar'].filter((t) => !meals.some((m) => m.type === t))
  return (
    <div>
      <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div><p className="text-sm capitalize text-mute">{date}</p>
          <h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">{greet}, Alex.</h1>
          <p className="mt-1 text-sm text-mute">Você treinou {done} de 4 dias previstos nesta semana.</p></div>
        <DemoTag />
      </header>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Foco principal: próximo treino */}
        <Card raised className="relative overflow-hidden lg:col-span-2">
          <div aria-hidden className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-brand/10 blur-3xl" />
          <div className="relative">
            <Badge tone={next.status === 'andamento' ? 'info' : 'accent'}>{next.status === 'andamento' ? 'Em andamento' : 'Próximo treino'}</Badge>
            <h2 className="mt-3 text-3xl font-extrabold tracking-tight sm:text-4xl">{next.name}</h2>
            <p className="mt-1 text-sm text-mute">{next.exercises.length} exercícios · {next.groups.join(', ')}</p>
            <div className="mt-5 flex items-end gap-8">
              <div><p className="num text-4xl font-extrabold">{next.minutes}<span className="ml-1 text-base font-semibold text-mute">min</span></p><p className="text-xs text-mute">duração estimada</p></div>
              <div><p className="num text-4xl font-extrabold">{next.exercises.reduce((a, e) => a + e.sets, 0)}</p><p className="text-xs text-mute">séries no total</p></div>
            </div>
            <ul className="mt-5 flex flex-wrap gap-2" aria-label="Exercícios do treino">{next.exercises.slice(0, 3).map((e) => (
              <li key={e.id}><button onClick={() => openWorkout(next.id, e.name)} aria-label={`Ver demonstração de ${e.name}`} className="flex h-10 items-center gap-2 rounded-full border border-line bg-surface/60 px-3.5 text-xs font-bold text-mute hover:border-brand hover:text-ink"><Icon n="play" s={12} className="text-brand" />{e.name}</button></li>))}</ul>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button onClick={() => openWorkout(next.id)}><Icon n="play" s={16} />{next.status === 'andamento' ? 'Continuar treino' : 'Iniciar treino'}</Button>
              <Button variant="secondary" onClick={() => go('train')}>Ver todos os treinos</Button>
            </div>
          </div>
        </Card>

        <Card>
          <SectionTitle title="Esta semana" hint={`${totalMin} min de atividade`} />
          <div className="flex h-28 items-end justify-between gap-2" role="img" aria-label={`Minutos de treino por dia: ${WEEK.map((d) => `${d.d} ${d.min}`).join(', ')}`}>
            {WEEK.map((d) => (
              <div key={d.d} className="flex flex-1 flex-col items-center gap-2">
                <div className={`w-full rounded-md ${d.done ? 'bg-brand' : 'bg-raised'}`} style={{ height: d.done ? `${Math.max(18, (d.min / max) * 100)}%` : '6px' }} />
                <span className="text-[11px] font-semibold text-mute">{d.d[0]}</span>
              </div>
            ))}
          </div>
          <p className="mt-4 flex items-center gap-2 text-xs text-mute"><span className="h-2.5 w-2.5 rounded-sm bg-brand" />Treino concluído<span className="ml-3 h-2.5 w-2.5 rounded-sm bg-raised" />Sem treino</p>
        </Card>

        <Card>
          <SectionTitle title="Nutrição do dia" hint="Estimativas informadas por você" action={<button onClick={() => go('food')} className="text-xs font-bold text-brand hover:underline">Abrir</button>} />
          <div className="flex items-center gap-5">
            <Ring value={tot.k} max={GOALS.kcal} size={112} label={`${tot.k} de ${GOALS.kcal} calorias`}>
              <span className="num text-xl font-extrabold">{tot.k}</span><span className="text-[10px] text-mute">de {GOALS.kcal} kcal</span></Ring>
            <div className="flex-1 space-y-3 text-xs">
              {([['Proteína', tot.p, GOALS.p], ['Carboidrato', tot.c, GOALS.c], ['Gordura', tot.f, GOALS.f]] as const).map(([l, v, g]) => (
                <div key={l}><div className="mb-1 flex justify-between"><span className="text-mute">{l}</span><span className="num font-bold">{v}/{g} g</span></div><Progress value={v} max={g} label={l} /></div>
              ))}
            </div>
          </div>
        </Card>

        <Card>
          <SectionTitle title="Hidratação" hint={`Meta de ${GOALS.water / 1000} L`} />
          <p className="num text-3xl font-extrabold">{(water / 1000).toFixed(2).replace('.', ',')}<span className="ml-1 text-sm font-semibold text-mute">L</span></p>
          <div className="my-3"><Progress tone="info" value={water} max={GOALS.water} label="Hidratação diária" /></div>
          <p className="mb-4 text-xs text-mute">{water >= GOALS.water ? 'Meta de hoje atingida.' : `Faltam ${((GOALS.water - water) / 1000).toFixed(2).replace('.', ',')} L.`}</p>
          <div className="flex gap-2">
            <Button size="sm" variant="secondary" className="flex-1" onClick={() => { addWater(250); toast('+250 ml registrados') }}><Icon n="drop" s={14} />250 ml</Button>
            <Button size="sm" variant="secondary" className="flex-1" onClick={() => { addWater(500); toast('+500 ml registrados') }}><Icon n="drop" s={14} />500 ml</Button>
          </div>
        </Card>

        <Card>
          <SectionTitle title="Atenção de hoje" />
          <ul className="space-y-3 text-sm">
            {missing.length > 0 && <li className="flex gap-3"><Icon n="alert" s={18} className="mt-0.5 text-warn" /><span><b>Refeições pendentes</b><span className="block text-xs text-mute">{missing.join(' e ')} ainda não registrado(s).</span></span></li>}
            <li className="flex gap-3"><Icon n="flame" s={18} className="mt-0.5 text-brand" /><span><b>Consistência: {done}/4</b><span className="block text-xs text-mute">Mais um treino fecha a meta semanal.</span></span></li>
          </ul>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Button size="sm" variant="secondary" onClick={() => go('food')}><Icon n="plus" s={14} />Refeição</Button>
            <Button size="sm" variant="secondary" onClick={() => go('prog')}><Icon n="prog" s={14} />Progresso</Button>
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <SectionTitle title="Refeições recentes" action={<button onClick={() => go('food')} className="text-xs font-bold text-brand hover:underline">Ver todas</button>} />
          <ul className="divide-y divide-line">
            {[...meals].sort((a, b) => b.time.localeCompare(a.time)).slice(0, 3).map((m) => (
              <li key={m.id} className="flex items-center gap-4 py-3 first:pt-0 last:pb-0">
                <span className="num w-12 text-sm font-bold text-mute">{m.time}</span>
                <div className="min-w-0 flex-1"><p className="text-sm font-bold">{m.type}</p><p className="truncate text-xs text-mute">{m.desc}</p></div>
                <span className="num text-sm font-bold">{m.kcal} kcal</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionTitle title="Prioridades musculares" action={<button onClick={() => go('train', 'priorities')} className="text-xs font-bold text-brand hover:underline">Editar</button>} />
          {priorities.length === 0 ? <p className="text-sm text-mute">Defina quais grupos você quer priorizar.</p> : (
            <ul className="space-y-2">{priorities.slice(0, 4).map((p, i) => <li key={p.id} className="flex items-center gap-3 text-sm"><span className="num w-4 font-extrabold text-mute">{i + 1}</span><span className="flex-1 font-semibold">{p.id}</span><Badge tone={p.level === 'alta' ? 'accent' : 'neutral'}>{p.level === 'media' ? 'Média' : p.level === 'alta' ? 'Alta' : 'Baixa'}</Badge></li>)}</ul>)}
        </Card>

        <Card>
          <SectionTitle title="Compartilhar evolução" hint="Crie um cartão da sua semana ou do seu mês." />
          <Button variant="secondary" size="sm" onClick={() => go('prog', 'share')}><Icon n="send" s={14} />Criar cartão</Button>
        </Card>

        <Card className="border-brand/30">
          <div className="mb-3 flex items-center gap-2"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand/15 text-brand"><Icon n="spark" s={16} /></span><h2 className="font-bold">Beyond AI</h2></div>
          <p className="text-sm text-mute">Dúvidas sobre treinos, execução, alimentação ou o app? Explore a biblioteca de perguntas.</p>
          <Button variant="secondary" size="sm" className="mt-4" onClick={() => go('chat')}>Abrir Beyond AI<Icon n="right" s={14} /></Button>
        </Card>
      </div>
    </div>
  )
}
