import { useState } from 'react'
import { useApp, type Level, type Priority } from '../lib/store'
import { BodyMap } from '../components/BodyMap'
import { Badge, Button, Card, DemoTag, EmptyState, Icon, IconButton, PageHeader, SectionTitle } from '../components/ui'
import { GROUPS } from '../lib/data'

const LV: [Level, string][] = [['alta', 'Alta'], ['media', 'Média'], ['baixa', 'Baixa']]
const FREQ: Record<Level, number> = { alta: 2, media: 2, baixa: 1 }
const DAYS = ['Seg', 'Ter', 'Qui', 'Sex']

// Distribuição ilustrativa: grupos de maior prioridade aparecem em mais dias. Não é prescrição de treino.
function plan(list: Priority[]) {
  const days: string[][] = DAYS.map(() => [])
  const order: Level[] = ['alta', 'media', 'baixa']
  list.slice().sort((a, b) => order.indexOf(a.level) - order.indexOf(b.level)).forEach((p) => {
    const n = p.level === 'media' ? 1 : FREQ[p.level]
    for (let k = 0; k < n; k++) {
      const cand = days.map((d, i) => ({ d, i })).filter((x) => !x.d.includes(p.id)).sort((a, b) => a.d.length - b.d.length || Math.abs(a.i - k * 2) - Math.abs(b.i - k * 2))
      cand[0]?.d.push(p.id)
    }
  })
  return days
}

export function Priorities() {
  const { priorities, setPriorities, go, toast } = useApp()
  const [draft, setDraft] = useState<Priority[]>(priorities)
  const [hover, setHover] = useState<string | null>(null)
  const [view, setView] = useState<'f' | 'b'>('f')
  const levels = Object.fromEntries(draft.map((p) => [p.id, p.level])) as Record<string, Level>
  const dirty = JSON.stringify(draft) !== JSON.stringify(priorities)
  const toggle = (id: string) => setDraft(levels[id] ? draft.filter((p) => p.id !== id) : [...draft, { id, level: 'media' }])
  const setLevel = (id: string, level: Level) => setDraft(draft.map((p) => (p.id === id ? { ...p, level } : p)))
  const move = (i: number, d: number) => { const n = [...draft]; [n[i], n[i + d]] = [n[i + d], n[i]]; setDraft(n) }
  const week = plan(draft)
  return (
    <div>
      <button onClick={() => go('train')} className="mb-4 inline-flex h-10 items-center gap-1 rounded-lg pr-3 text-sm font-semibold text-mute hover:text-ink"><Icon n="back" s={18} />Treinos</button>
      <PageHeader title="Prioridades musculares" desc="Escolha os grupos que você quer priorizar. Elas servem de referência para organizar sua rotina." action={<DemoTag />} />
      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <Card className="lg:sticky lg:top-6 lg:self-start">
          <div role="tablist" aria-label="Vista do corpo" className="mb-3 flex rounded-xl border border-line p-1">
            {([['f', 'Frente'], ['b', 'Costas']] as const).map(([k, l]) => <button key={k} role="tab" aria-selected={view === k} onClick={() => setView(k)} className={`h-9 flex-1 rounded-lg text-sm font-semibold ${view === k ? 'bg-raised text-ink' : 'text-mute'}`}>{l}</button>)}
          </div>
          <div className="h-[380px]"><BodyMap view={view} levels={levels} onPick={toggle} hover={hover} setHover={setHover} /></div>
          <p className="mt-2 h-5 text-center text-sm font-bold">{hover ?? <span className="font-medium text-mute">Toque em um músculo</span>}</p>
          <div className="mt-2 flex items-center justify-center gap-3 text-[11px] text-mute">
            {LV.map(([k, l], i) => <span key={k} className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-sm bg-brand" style={{ opacity: [1, 0.6, 0.3][i] }} />{l}</span>)}
          </div>
        </Card>
        <div className="space-y-4">
          <Card>
            <SectionTitle title="Grupos musculares" hint="Selecione e defina o nível de prioridade de cada um." />
            <ul className="grid gap-2 sm:grid-cols-2">
              {GROUPS.map((g) => {
                const lv = levels[g]
                return (
                  <li key={g} onMouseEnter={() => setHover(g)} onMouseLeave={() => setHover(null)} className={`rounded-xl border p-3 ${lv ? 'border-brand/50 bg-brand/5' : 'border-line'}`}>
                    <button onClick={() => toggle(g)} aria-pressed={!!lv} className="flex min-h-10 w-full items-center gap-3 text-left">
                      <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 ${lv ? 'border-accent bg-accent text-accent-ink' : 'border-line'}`}>{lv && <Icon n="check" s={14} />}</span>
                      <span className="flex-1 text-sm font-bold">{g}</span>
                    </button>
                    {lv && <div role="group" aria-label={`Prioridade de ${g}`} className="mt-2 grid grid-cols-3 gap-1">{LV.map(([k, l]) => <button key={k} aria-pressed={lv === k} onClick={() => setLevel(g, k)} className={`h-10 rounded-lg text-xs font-bold ${lv === k ? 'bg-accent text-accent-ink' : 'bg-raised text-mute hover:text-ink'}`}>{l}</button>)}</div>}
                  </li>
                )
              })}
            </ul>
          </Card>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <SectionTitle title="Ordem de prioridade" hint="O primeiro da lista recebe mais atenção." />
              {draft.length === 0 ? <EmptyState icon="dumb" title="Nenhum grupo selecionado" desc="Escolha ao menos um grupo para montar sua ordem." /> : (
                <ol className="space-y-2">{draft.map((p, i) => (
                  <li key={p.id} className="flex items-center gap-2 rounded-xl bg-raised px-3 py-2">
                    <span className="num w-5 text-sm font-extrabold text-mute">{i + 1}</span><span className="flex-1 text-sm font-bold">{p.id}</span>
                    <Badge tone={p.level === 'alta' ? 'accent' : 'neutral'}>{p.level === 'media' ? 'Média' : p.level === 'alta' ? 'Alta' : 'Baixa'}</Badge>
                    <IconButton label={`Subir ${p.id}`} n="left" className="-rotate-90" disabled={i === 0} onClick={() => move(i, -1)} />
                    <IconButton label={`Descer ${p.id}`} n="right" className="rotate-90" disabled={i === draft.length - 1} onClick={() => move(i, 1)} />
                  </li>))}</ol>
              )}
            </Card>
            <Card>
              <SectionTitle title="Como isso organiza a semana" hint="Exemplo ilustrativo com 4 dias de treino." />
              {draft.length === 0 ? <p className="text-sm text-mute">Sem prioridades, a distribuição semanal não é exibida.</p> : (
                <ul className="space-y-2">{DAYS.map((d, i) => <li key={d} className="flex items-start gap-3 text-sm"><span className="w-9 pt-1 text-xs font-bold text-mute">{d}</span>
                  <div className="flex flex-1 flex-wrap gap-1.5">{week[i].length ? week[i].map((g) => <span key={g} className="rounded-md bg-raised px-2 py-1 text-xs font-semibold">{g}</span>) : <span className="pt-1 text-xs text-mute">Livre</span>}</div></li>)}</ul>
              )}
              <p className="mt-3 text-[11px] leading-relaxed text-mute">Grupos de prioridade alta aparecem em mais dias. Não é uma prescrição profissional, e ainda não há algoritmo de montagem automática implementado.</p>
            </Card>
          </div>
          <div className="sticky bottom-20 flex flex-wrap justify-end gap-2 lg:bottom-4">
            <Button variant="secondary" disabled={!dirty} onClick={() => setDraft(priorities)}>Descartar</Button>
            <Button disabled={!dirty} className="shadow-lg" onClick={() => { setPriorities(draft); toast('Prioridades salvas nesta sessão') }}>Salvar prioridades</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
