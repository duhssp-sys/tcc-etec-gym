import { useState } from 'react'
import { useApp } from '../lib/store'
import { Badge, Button, Card, EmptyState, Icon, IconButton, Modal, Progress, SectionTitle, Select } from '../components/ui'
import { ExerciseDemo } from '../components/ExerciseDemo'
import { EXERCISE_LIBRARY } from '../lib/exercises'
import { GROUPS, type Exercise, type Workout } from '../lib/data'

export function WorkoutSession({ workout }: { workout: Workout }) {
  const { workouts, setWorkouts, openWorkout, toast, demoEx } = useApp()
  const [sheet, setSheet] = useState<string | null>(workout.exercises.find((e) => e.name === demoEx)?.id ?? null)
  const [doneSets, setDoneSets] = useState<Record<string, number>>({})
  const [cur, setCur] = useState(workout.exercises[0]?.id ?? '')
  const [grp, setGrp] = useState('Peito')
  const sheetEx = workout.exercises.find((e) => e.id === sheet)
  const [finishing, setFinishing] = useState(false)
  const update = (ex: Exercise[]) => setWorkouts(workouts.map((w) => (w.id === workout.id ? { ...w, exercises: ex } : w)))
  const edit = (id: string, k: 'kg' | 'reps', v: number) => update(workout.exercises.map((e) => (e.id === id ? { ...e, [k]: Math.max(0, v) } : e)))
  const totalSets = workout.exercises.reduce((a, e) => a + e.sets, 0)
  const doneTotal = workout.exercises.reduce((a, e) => a + Math.min(doneSets[e.id] ?? 0, e.sets), 0)
  const exDone = (e: Exercise) => (doneSets[e.id] ?? 0) >= e.sets
  const toggle = (e: Exercise) => setDoneSets((d) => ({ ...d, [e.id]: exDone(e) ? 0 : e.sets }))
  const current = workout.exercises.find((e) => e.id === cur) ?? workout.exercises[0]
  const finish = () => {
    setFinishing(true)
    setTimeout(() => {
      setWorkouts(workouts.map((w) => (w.id === workout.id ? { ...w, status: 'concluido', last: 'Hoje' } : w)))
      toast('Treino finalizado. Bom trabalho!'); openWorkout(null)
    }, 700)
  }
  const mark = (e: Exercise) => { const n = Math.min(e.sets, (doneSets[e.id] ?? 0) + 1); setDoneSets({ ...doneSets, [e.id]: n }); toast(`Série ${n}/${e.sets} de ${e.name}`) }
  return (
    <div>
      <button onClick={() => openWorkout(null)} className="mb-4 inline-flex h-10 items-center gap-1 rounded-lg pr-3 text-sm font-semibold text-mute hover:text-ink"><Icon n="back" s={18} />Treinos</button>
      <header className="mb-5">
        <div className="flex flex-wrap items-center gap-2"><Badge tone="info">Sessão em andamento</Badge>{workout.groups.map((g) => <Badge key={g}>{g}</Badge>)}</div>
        <h1 className="mt-2 text-2xl font-extrabold tracking-tight sm:text-3xl">{workout.name}</h1>
        <div className="mt-4 flex items-center gap-4"><div className="flex-1"><Progress value={doneTotal} max={totalSets || 1} label="Progresso do treino" /></div>
          <span className="num text-sm font-bold">{doneTotal}/{totalSets} séries</span></div>
      </header>
      {workout.exercises.length === 0 ? <EmptyState icon="dumb" title="Rotina sem exercícios" desc="Adicione exercícios abaixo para montar este treino." /> : (
        <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
          <ol className="space-y-3">
            {workout.exercises.map((e, i) => {
              const d = exDone(e), sel = current?.id === e.id
              return (
                <li key={e.id}><Card className={`!p-4 ${sel ? 'border-brand/50' : ''} ${d ? 'opacity-70' : ''}`}>
                  <div className="flex items-center gap-3">
                    <button aria-label={d ? `Desmarcar ${e.name}` : `Concluir ${e.name}`} aria-pressed={d} onClick={() => toggle(e)} className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border-2 ${d ? 'border-brand bg-accent text-accent-ink' : 'border-line text-mute hover:border-mute'}`}>{d ? <Icon n="check" s={22} /> : <span className="num font-extrabold">{i + 1}</span>}</button>
                    <button onClick={() => setCur(e.id)} className="min-w-0 flex-1 text-left"><p className={`font-bold ${d ? 'line-through' : ''}`}>{e.name}</p><p className="text-xs text-mute">{e.group} · {e.sets}×{e.reps} · descanso {e.rest}s</p></button>
                    <span className="num hidden text-sm font-bold text-mute sm:block">{doneSets[e.id] ?? 0}/{e.sets}</span>
                    <IconButton label={`Ver demonstração de ${e.name}`} n="play" onClick={() => { setCur(e.id); setSheet(e.id) }} />
                    <IconButton label={`Remover ${e.name}`} n="trash" onClick={() => update(workout.exercises.filter((x) => x.id !== e.id))} />
                  </div>
                  <div className="mt-4 grid grid-cols-[1fr_1fr_auto] items-end gap-3">
                    {([['kg', 'Carga (kg)', 2.5], ['reps', 'Repetições', 1]] as const).map(([k, l, step]) => (
                      <div key={k}><span className="mb-1.5 block text-xs font-semibold text-mute">{l}</span>
                        <div className="flex h-12 items-center rounded-xl border border-control bg-bg">
                          <button aria-label={`Diminuir ${l}`} onClick={() => edit(e.id, k, e[k] - step)} className="h-full w-12 text-mute hover:text-ink"><Icon n="minus" s={16} className="mx-auto" /></button>
                          <input aria-label={`${l} de ${e.name}`} inputMode="decimal" type="number" value={e[k]} onChange={(ev) => edit(e.id, k, +ev.target.value)} className="num w-full min-w-0 bg-transparent text-center text-lg font-bold focus:outline-none" />
                          <button aria-label={`Aumentar ${l}`} onClick={() => edit(e.id, k, e[k] + step)} className="h-full w-12 text-mute hover:text-ink"><Icon n="plus" s={16} className="mx-auto" /></button>
                        </div></div>
                    ))}
                    <Button disabled={d} className="h-12" onClick={() => mark(e)}>Série {Math.min((doneSets[e.id] ?? 0) + 1, e.sets)}</Button>
                  </div>
                </Card></li>
              )
            })}
          </ol>
          <aside className="space-y-4 lg:sticky lg:top-6 lg:self-start">
            {current && <Card className="hidden lg:block"><ExerciseDemo ex={current} done={exDone(current)} onComplete={() => toggle(current)} /></Card>}
            <Button className="w-full" loading={finishing} disabled={doneTotal === 0} onClick={finish}>Finalizar sessão</Button>
            {doneTotal < totalSets && doneTotal > 0 && <p className="text-center text-xs text-mute">Ainda há {totalSets - doneTotal} série(s) pendente(s). Você pode finalizar mesmo assim.</p>}
          </aside>
        </div>
      )}
      <Card className="mt-6">
        <SectionTitle title="Adicionar exercício" />
        <div className="flex flex-wrap items-end gap-3">
          <Select label="Grupo muscular" value={grp} onChange={(e) => setGrp(e.target.value)} className="w-40">{GROUPS.map((g) => <option key={g}>{g}</option>)}</Select>
          <div className="flex flex-1 flex-wrap gap-2">{EXERCISE_LIBRARY[grp].map((n) => (
            <Button key={n} variant="secondary" size="sm" onClick={() => { const ne = { id: Math.random().toString(36).slice(2, 8), name: n, group: grp, sets: 3, reps: 10, kg: 0, rest: 60 }; update([...workout.exercises, ne]); if (!cur) setCur(ne.id) }}><Icon n="plus" s={14} />{n}</Button>))}</div>
        </div>
      </Card>
      <Modal open={!!sheetEx} onClose={() => setSheet(null)} title="Demonstração do exercício">
        {sheetEx && <ExerciseDemo ex={sheetEx} done={exDone(sheetEx)} onComplete={() => { toggle(sheetEx); setSheet(null) }} />}
      </Modal>
    </div>
  )
}
