import { useState } from 'react'
import { Card, DemoTag, EmptyState, PageHeader, SectionTitle, Segmented, Badge } from '../components/ui'
import { HISTORY, LOAD_SERIES, SESSIONS } from '../lib/data'
import { Button, Icon } from '../components/ui'
import { useApp } from '../lib/store'
import { ShareStudio } from './ShareStudio'

function Bars({ data, unit, label }: { data: number[]; unit: string; label: string }) {
  const mx = Math.max(...data, 1), top = Math.ceil(mx / 2) * 2
  return (
    <div role="img" aria-label={`${label}: ${data.join(', ')} ${unit}`} className="flex gap-2">
      <div className="flex h-40 flex-col justify-between pb-6 text-[10px] text-mute num"><span>{top}</span><span>{top / 2}</span><span>0</span></div>
      <div className="flex-1"><div className="relative flex h-40 items-end gap-2 border-b border-line pb-0">
        {[0, 50].map((p) => <div key={p} aria-hidden className="absolute inset-x-0 border-t border-dashed border-line/60" style={{ bottom: `calc(${p}% + 24px)` }} />)}
        {data.map((v, i) => <div key={i} className="relative z-10 flex flex-1 flex-col items-center justify-end gap-1" style={{ height: '100%' }}>
          <span className="num text-[11px] font-bold">{v}</span><div className="w-full max-w-10 rounded-t-md bg-brand" style={{ height: `${(v / top) * 100 - 15}%`, minHeight: 4 }} />
          <span className="h-5 text-[10px] text-mute">{i + 1}</span></div>)}
      </div></div>
    </div>
  )
}
function Line({ data }: { data: { x: string; y: number }[] }) {
  const ys = data.map((d) => d.y), mn = Math.min(...ys) - 2.5, mx = Math.max(...ys) + 2.5
  const X = (i: number) => 36 + (i / (data.length - 1)) * 330, Y = (y: number) => 10 + (1 - (y - mn) / (mx - mn)) * 100
  return (
    <svg viewBox="0 0 380 140" className="w-full" role="img" aria-label={`Carga do supino reto em kg: ${data.map((d) => `${d.x} ${d.y}`).join(', ')}`}>
      {[mn + 2.5, (mn + mx) / 2, mx - 2.5].map((v) => <g key={v}><line x1="36" x2="370" y1={Y(v)} y2={Y(v)} stroke="var(--color-line)" strokeDasharray="3 3" /><text x="0" y={Y(v) + 3} fontSize="10" fill="var(--color-mute)">{v.toFixed(0)} kg</text></g>)}
      <polyline points={data.map((d, i) => `${X(i)},${Y(d.y)}`).join(' ')} fill="none" stroke="var(--color-brand)" strokeWidth="2.5" strokeLinejoin="round" />
      {data.map((d, i) => <g key={d.x}><circle cx={X(i)} cy={Y(d.y)} r="4" fill="var(--color-bg)" stroke="var(--color-brand)" strokeWidth="2" /><text x={X(i)} y="132" fontSize="10" textAnchor="middle" fill="var(--color-mute)">{d.x}</text></g>)}
    </svg>
  )
}

export function Progress() {
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('30d')
  const { view, go } = useApp()
  const [share, setShare] = useState(false)
  if (share || view === 'share') return <ShareStudio onBack={() => { setShare(false); go('prog') }} />
  const h = HISTORY[period]
  const hasData = h.freq.length >= 2
  const avg = hasData ? (h.freq.reduce((a, b) => a + b, 0) / h.freq.length).toFixed(1).replace('.', ',') : '—'
  return (
    <div>
      <PageHeader title="Progresso" desc="Acompanhe sua constância e a evolução das cargas ao longo do tempo." action={<Button variant="secondary" onClick={() => setShare(true)}><Icon n="send" s={16} />Compartilhar evolução</Button>} />
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <Segmented label="Período" value={period} onChange={setPeriod} options={[['7d', '7 dias'], ['30d', '30 dias'], ['90d', '90 dias']]} /><DemoTag>Gráficos com dados demonstrativos</DemoTag>
      </div>
      {!hasData ? <EmptyState icon="prog" title="Dados insuficientes neste período" desc="São necessárias ao menos duas semanas de treinos registrados para exibir tendências. Continue registrando suas sessões." /> : (
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="grid grid-cols-3 gap-4 lg:col-span-3">
            {[['Treinos / semana', avg, 'média no período'], ['Duração média', '54 min', 'por sessão'], ['Consistência', '4 de 4', 'semanas com meta cumprida']].map(([l, v, s]) => (
              <Card key={l} className="!p-4"><p className="text-[11px] font-semibold text-mute sm:text-xs">{l}</p><p className="num mt-1 text-xl font-extrabold sm:text-3xl">{v}</p><p className="mt-0.5 text-[11px] text-mute">{s}</p></Card>))}
          </div>
          <Card className="lg:col-span-2"><SectionTitle title="Frequência semanal" hint={`Treinos concluídos por semana · ${h.label}`} action={<Badge>Atividade</Badge>} /><Bars data={h.freq} unit="treinos" label="Treinos por semana" /><p className="mt-2 text-center text-[11px] text-mute">Semana no período</p></Card>
          <Card><SectionTitle title="Últimas sessões" /><ul className="divide-y divide-line">{SESSIONS.map((s) => <li key={s.date + s.name} className="flex items-center gap-3 py-2.5 first:pt-0 last:pb-0"><span className="num w-11 text-xs font-bold text-mute">{s.date}</span><span className="flex-1 text-sm font-semibold">{s.name}</span><span className="num text-xs text-mute">{s.min} min</span></li>)}</ul></Card>
          <Card className="lg:col-span-2"><SectionTitle title="Evolução de carga: supino reto" hint="Maior carga registrada por semana (kg)" action={<Badge tone="info">Resultado</Badge>} /><Line data={LOAD_SERIES} /></Card>
          <Card><SectionTitle title="Hidratação e alimentação" /><p className="text-sm text-mute">Os registros de refeições e água de dias anteriores só aparecerão aqui quando a persistência de dados for implementada.</p></Card>
        </div>
      )}
      <p className="mt-5 text-xs text-mute">Atividade (frequência, duração) mede o que você fez; resultado (cargas) mede desempenho. Nenhum indicador aqui avalia condição física ou saúde.</p>
    </div>
  )
}
