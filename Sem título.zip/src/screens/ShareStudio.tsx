import { useRef, useState } from 'react'
import { useApp } from '../lib/store'
import { Badge, Button, Card, DemoTag, Icon, PageHeader, Segmented, SectionTitle, Toggle } from '../components/ui'

type Period = 'dia' | 'semana' | 'mes' | 'ano'
type Fmt = 'v' | 's' | 'h'
type Stat = { key: string; label: string; value: string | null; note?: string }
// Dados demonstrativos por período. `null` = sem dados: o indicador não é exibido nem pode ser compartilhado.
const PERIODS: Record<Period, { title: string; ref: string; headline: [string, string]; stats: Stat[] }> = {
  dia: { title: 'Resumo do dia', ref: 'Hoje', headline: ['1', 'treino concluído'], stats: [
    { key: 'dur', label: 'Duração', value: '65 min' }, { key: 'ex', label: 'Exercícios concluídos', value: '4' }, { key: 'meta', label: 'Meta do dia', value: 'Cumprida' },
    { key: 'freq', label: 'Frequência', value: null, note: 'Disponível a partir de 2 dias' }, { key: 'carga', label: 'Evolução de carga', value: null, note: 'Sem comparação no dia' }, { key: 'cons', label: 'Consistência', value: null, note: 'Requer uma semana' }] },
  semana: { title: 'Resumo da semana', ref: 'Semana atual', headline: ['3', 'treinos na semana'], stats: [
    { key: 'dur', label: 'Duração total', value: '170 min' }, { key: 'ex', label: 'Exercícios concluídos', value: '11' }, { key: 'freq', label: 'Frequência', value: '3 de 4 dias' },
    { key: 'carga', label: 'Evolução de carga', value: '+5 kg', note: 'Supino reto' }, { key: 'cons', label: 'Consistência', value: '75%' }, { key: 'meta', label: 'Meta semanal', value: 'Falta 1 treino' }] },
  mes: { title: 'Resumo do mês', ref: 'Últimos 30 dias', headline: ['14', 'treinos no mês'], stats: [
    { key: 'dur', label: 'Duração total', value: '12 h 20 min' }, { key: 'ex', label: 'Exercícios concluídos', value: '52' }, { key: 'freq', label: 'Frequência', value: '3,8 por semana' },
    { key: 'carga', label: 'Evolução de carga', value: '+10 kg', note: 'Supino reto' }, { key: 'cons', label: 'Consistência', value: '4 de 4 semanas' }, { key: 'meta', label: 'Meta mensal', value: 'Alcançada' }] },
  ano: { title: 'Resumo do ano', ref: 'Ano atual', headline: ['118', 'treinos no ano'], stats: [
    { key: 'dur', label: 'Duração total', value: '104 h' }, { key: 'ex', label: 'Exercícios concluídos', value: '436' }, { key: 'freq', label: 'Frequência', value: '3,4 por semana' },
    { key: 'cons', label: 'Consistência', value: '41 de 48 semanas' }, { key: 'meta', label: 'Metas alcançadas', value: '9 de 12 meses' },
    { key: 'carga', label: 'Evolução de carga', value: null, note: 'Sem histórico de cargas suficiente' }] },
}
const SIZES: Record<Fmt, [number, number, string]> = { v: [1080, 1920, 'Vertical 9:16'], s: [1080, 1080, 'Quadrado 1:1'], h: [1920, 1080, 'Horizontal 16:9'] }
const FONT = "Manrope, 'Segoe UI', Arial, sans-serif"

function Card2({ id, period, fmt, show, name, dark }: { id: string; period: Period; fmt: Fmt; show: Record<string, boolean>; name: boolean; dark: boolean }) {
  const [W, H] = SIZES[fmt], d = PERIODS[period]
  const c = dark ? { bg: '#0b1320', bg2: '#16233f', ink: '#ffffff', mute: '#9aa8c4', acc: '#8fa7ee', tile: '#152238', line: '#263757' } : { bg: '#f4f6fa', bg2: '#dfe6f5', ink: '#172033', mute: '#5f6878', acc: '#384c87', tile: '#ffffff', line: '#dce2ec' }
  const items = d.stats.filter((s) => s.value && show[s.key]).slice(0, 6)
  const lay = { v: { cols: 2, titleY: 400, refY: 465, headY: 690, hf: 210, top: 780, th: 210, gap: 28 }, s: { cols: 2, titleY: 270, refY: 320, headY: 505, hf: 170, top: 570, th: 120, gap: 20 }, h: { cols: 3, titleY: 250, refY: 300, headY: 410, hf: 120, top: 450, th: 190, gap: 28 } }[fmt]
  const pad = 90, cols = lay.cols, compact = fmt === 's'
  const tileW = (W - pad * 2 - (cols - 1) * lay.gap) / cols
  return (
    <svg id={id} xmlns="http://www.w3.org/2000/svg" viewBox={`0 0 ${W} ${H}`} width={W} height={H} className="block h-auto w-full" role="img" aria-label={`Cartão de compartilhamento: ${d.title}`} style={{ fontFamily: FONT }}>
      <defs><linearGradient id={`${id}g`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={c.bg} /><stop offset="1" stopColor={c.bg2} /></linearGradient></defs>
      <rect width={W} height={H} fill={`url(#${id}g)`} />
      <circle cx={W - 120} cy={140} r={fmt === 'h' ? 330 : 380} fill="#384c87" opacity={dark ? 0.35 : 0.16} />
      <rect x={pad} y={pad} width="84" height="84" rx="22" fill="#384c87" />
      <path d={`M${pad + 20} ${pad + 58} l16 -16 10 10 24 -28 M${pad + 54} ${pad + 24} h14 v14`} fill="none" stroke="#fff" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      <text x={pad + 108} y={pad + 38} fontSize="38" fontWeight="800" fill={c.ink}>Beyond</text>
      <text x={pad + 108} y={pad + 80} fontSize="38" fontWeight="800" fill={c.mute}>Training</text>
      <text x={pad} y={lay.titleY} fontSize="34" fontWeight="700" fill={c.acc} letterSpacing="3">{d.title.toUpperCase()}</text>
      <text x={pad} y={lay.refY} fontSize="30" fill={c.mute}>{d.ref}{name ? ' · Alex Lima' : ''}</text>
      {show.headline && <g>
        <text x={pad} y={lay.headY} fontSize={lay.hf} fontWeight="800" fill={c.ink} letterSpacing="-6">{d.headline[0]}</text>
        <text x={pad + d.headline[0].length * lay.hf * 0.58 + 28} y={lay.headY} fontSize="42" fontWeight="600" fill={c.mute}>{d.headline[1]}</text></g>}
      {items.map((s, i) => {
        const x = pad + (i % cols) * (tileW + lay.gap), y = lay.top + Math.floor(i / cols) * (lay.th + lay.gap)
        return (<g key={s.key}><rect x={x} y={y} width={tileW} height={lay.th} rx="28" fill={c.tile} stroke={c.line} strokeWidth="2" />
          <text x={x + 32} y={y + (compact ? 44 : 60)} fontSize={compact ? 24 : 27} fill={c.mute}>{s.label}{compact && s.note ? ` · ${s.note}` : ''}</text>
          <text x={x + 32} y={y + (compact ? 96 : 135)} fontSize={s.value!.length > 11 ? 42 : compact ? 50 : 56} fontWeight="800" fill={c.ink}>{s.value}</text>
          {!compact && s.note && <text x={x + 32} y={y + 172} fontSize="24" fill={c.acc}>{s.note}</text>}</g>)
      })}
      {items.length === 0 && <text x={pad} y={lay.top + 60} fontSize="34" fill={c.mute}>Nenhuma informação selecionada</text>}
      <text x={pad} y={H - 60} fontSize="24" fill={c.mute}>Cartão de exemplo com dados demonstrativos · Beyond Training</text>
    </svg>
  )
}

export function ShareStudio({ onBack }: { onBack: () => void }) {
  const { toast } = useApp()
  const [period, setPeriod] = useState<Period>('semana')
  const [fmt, setFmt] = useState<Fmt>('s')
  const [dark, setDark] = useState(true)
  const [name, setName] = useState(false)
  const [busy, setBusy] = useState(false)
  const [show, setShow] = useState<Record<string, boolean>>({ headline: true, dur: true, ex: true, freq: true, carga: true, cons: true, meta: true })
  const d = PERIODS[period]
  const wrap = useRef<HTMLDivElement>(null)

  const toPng = () => new Promise<Blob>((res, rej) => {
    const svg = wrap.current?.querySelector('svg'); if (!svg) return rej(new Error('sem cartão'))
    const [W, H] = SIZES[fmt]
    const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml;charset=utf-8' }))
    const img = new Image()
    img.onload = () => { const cv = document.createElement('canvas'); cv.width = W; cv.height = H; cv.getContext('2d')!.drawImage(img, 0, 0, W, H); URL.revokeObjectURL(url); cv.toBlob((b) => (b ? res(b) : rej(new Error('falha'))), 'image/png') }
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('falha')) }
    img.src = url
  })
  const file = `beyond-training-${period}-${fmt}.png`
  const download = async () => {
    setBusy(true)
    try { const b = await toPng(); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = file; a.click(); toast('Imagem exportada') } catch { toast('Não foi possível gerar a imagem', 'bad') }
    setBusy(false)
  }
  const share = async () => {
    setBusy(true)
    try {
      const b = await toPng(), f = new File([b], file, { type: 'image/png' })
      if (navigator.canShare?.({ files: [f] })) { await navigator.share({ files: [f], title: 'Minha evolução no Beyond Training' }) }
      else toast('Seu navegador não abre o compartilhamento nativo. Baixe a imagem e publique manualmente.', 'info')
    } catch (e) { if ((e as Error).name !== 'AbortError') toast('Não foi possível compartilhar', 'bad') }
    setBusy(false)
  }
  const fields: [string, string][] = [['headline', 'Treinos realizados'], ...d.stats.map((s): [string, string] => [s.key, s.label])]
  const avail = (k: string) => k === 'headline' || !!d.stats.find((s) => s.key === k)?.value
  return (
    <div>
      <button onClick={onBack} className="mb-4 inline-flex h-10 items-center gap-1 rounded-lg pr-3 text-sm font-semibold text-mute hover:text-ink"><Icon n="back" s={18} />Progresso</button>
      <PageHeader title="Compartilhar evolução" desc="Crie um cartão com os resultados que você quiser mostrar. Nada é exibido sem a sua escolha." action={<DemoTag />} />
      <div className="mb-5"><Segmented label="Período" value={period} onChange={setPeriod} options={[['dia', 'Diário'], ['semana', 'Semanal'], ['mes', 'Mensal'], ['ano', 'Anual']]} /></div>
      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <Card className="order-2 lg:order-1">
          <SectionTitle title="Prévia" hint={`${SIZES[fmt][2]} · ${d.ref}`} action={<Badge tone="warn">Exemplo</Badge>} />
          <div ref={wrap} className={`mx-auto ${fmt === 'v' ? 'max-w-[300px]' : fmt === 's' ? 'max-w-[460px]' : 'max-w-full'} overflow-hidden rounded-xl border border-line`}>
            <Card2 id="share-card" period={period} fmt={fmt} show={show} name={name} dark={dark} />
          </div>
        </Card>
        <div className="order-1 space-y-4 lg:order-2">
          <Card>
            <SectionTitle title="Formato" />
            <div className="grid grid-cols-3 gap-2">{(Object.keys(SIZES) as Fmt[]).map((k) => <button key={k} aria-pressed={fmt === k} onClick={() => setFmt(k)} className={`min-h-12 rounded-xl border px-2 text-xs font-bold ${fmt === k ? 'border-brand bg-brand/10 text-brand' : 'border-line text-mute hover:text-ink'}`}>{SIZES[k][2].split(' ')[0]}<span className="block font-medium opacity-80">{SIZES[k][2].split(' ')[1]}</span></button>)}</div>
            <div className="mt-3"><Segmented label="Estilo do cartão" value={dark ? 'e' : 'c'} onChange={(v) => setDark(v === 'e')} options={[['e', 'Escuro'], ['c', 'Claro']]} /></div>
          </Card>
          <Card>
            <SectionTitle title="O que exibir" hint="Indicadores sem dados ficam indisponíveis." />
            <ul className="divide-y divide-line">
              {fields.map(([k, l]) => { const ok = avail(k); return (
                <li key={k} className="flex items-center justify-between gap-3 py-2.5 first:pt-0">
                  <div><p className={`text-sm font-semibold ${ok ? '' : 'text-mute'}`}>{l}</p>{!ok && <p className="text-[11px] text-mute">{d.stats.find((s) => s.key === k)?.note ?? 'Sem dados no período'}</p>}</div>
                  <Toggle label={l} checked={ok && show[k]} onChange={(v) => ok && setShow({ ...show, [k]: v })} />
                </li>) })}
              <li className="flex items-center justify-between gap-3 py-2.5 last:pb-0"><div><p className="text-sm font-semibold">Meu nome</p><p className="text-[11px] text-mute">Oculto por padrão (privacidade)</p></div><Toggle label="Exibir meu nome" checked={name} onChange={setName} /></li>
            </ul>
          </Card>
          <div className="flex gap-2">
            <Button className="flex-1" variant="secondary" loading={busy} onClick={download}>Baixar PNG</Button>
            <Button className="flex-1" loading={busy} onClick={share}>Compartilhar</Button>
          </div>
          <p className="text-[11px] leading-relaxed text-mute">Isto cria uma imagem. A publicação direta no Instagram, Facebook ou outras redes depende de integração externa, ainda não implementada.</p>
        </div>
      </div>
    </div>
  )
}
