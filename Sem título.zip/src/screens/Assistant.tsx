import { useEffect, useMemo, useRef, useState } from 'react'
import { useApp, type ChatMsg } from '../lib/store'
import { Badge, Button, Icon, IconButton, Toggle } from '../components/ui'
import { ALL_QS, CATEGORIES, answer } from '../lib/ai'

const KIND: Record<string, [string, 'warn' | 'info' | 'neutral']> = { sim: ['Simulação · resposta pré-cadastrada', 'warn'], safety: ['Aviso de segurança', 'info'], nodata: ['Sem dados suficientes', 'neutral'], error: ['Erro', 'neutral'] }
const CONTEXT = ['Treinos cadastrados', 'Prioridades musculares', 'Histórico de exercícios', 'Cargas registradas', 'Frequência de atividades', 'Refeições registradas']

export function Assistant() {
  const { chats, setChats, toast } = useApp()
  const [cur, setCur] = useState<string | null>(chats[0]?.id ?? null)
  const [cat, setCat] = useState('todas')
  const [search, setSearch] = useState('')
  const [t, setT] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [panel, setPanel] = useState<'lib' | 'hist' | 'ctx'>('lib')
  const end = useRef<HTMLDivElement>(null)
  const chatsRef = useRef(chats) // versão mais recente das conversas, lida dentro do timeout
  chatsRef.current = chats
  const chat = chats.find((c) => c.id === cur)
  useEffect(() => { end.current?.scrollIntoView({ block: 'end', behavior: 'smooth' }) }, [chat?.msgs.length, busy])

  const send = (q: string) => {
    q = q.trim(); if (!q || busy) return
    if (q.length > 400) return setErr('Mensagem muito longa. Resuma sua dúvida em até 400 caracteres.')
    setErr('')
    const id = chat?.id ?? Math.random().toString(36).slice(2, 8)
    const userMsg: ChatMsg = { me: true, text: q }
    setChats(chat ? chats.map((c) => (c.id === id ? { ...c, msgs: [...c.msgs, userMsg] } : c)) : [{ id, title: q.slice(0, 40), msgs: [userMsg] }, ...chats])
    setCur(id); setT(''); setBusy(true)
    setTimeout(() => {
      const a = answer(q)
      setChats(chatsRef.current.map((c) => (c.id === id ? { ...c, msgs: [...c.msgs, a] } : c)))
      setBusy(false)
    }, 900)
  }
  const copy = async (m: ChatMsg) => {
    const txt = [m.title, ...(m.steps?.map((s, i) => `${i + 1}. ${s}`) ?? []), m.text].filter(Boolean).join('\n')
    try { await navigator.clipboard.writeText(txt); toast('Resposta copiada') } catch { toast('Não foi possível copiar', 'bad') }
  }
  const newChat = () => { setCur(null); setT(''); setErr(''); setPanel('lib') }
  const list = useMemo(() => {
    const s = search.trim().toLowerCase()
    return ALL_QS.filter((x) => (cat === 'todas' || CATEGORIES.find((c) => c.id === cat)?.name === x.cat) && (!s || x.q.toLowerCase().includes(s)))
  }, [cat, search])

  return (
    <div>
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-accent text-accent-ink"><Icon n="spark" s={24} /></span>
          <div><h1 className="text-2xl font-extrabold tracking-tight sm:text-3xl">Beyond AI</h1><p className="text-sm text-mute">Tire dúvidas sobre treino, alimentação, hábitos e sobre o app.</p></div></div>
        <Button variant="secondary" onClick={newChat}><Icon n="plus" s={16} />Nova conversa</Button>
      </header>
      <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-warn/30 bg-warn/5 px-4 py-3 text-xs text-mute"><Icon n="info" s={16} className="mt-0.5 text-warn" />
        <p><b className="text-ink">Protótipo demonstrativo.</b> Não há modelo de IA conectado: as respostas são textos pré-cadastrados e identificadas como simulação. O Beyond AI não substitui médicos, nutricionistas ou profissionais de Educação Física.</p></div>

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <section className="flex min-h-[520px] flex-col rounded-card border border-line bg-surface lg:h-[calc(100dvh-17rem)]" aria-label="Conversa">
          <div className="flex-1 overflow-y-auto p-4 sm:p-5" role="log" aria-live="polite">
            {!chat ? (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <span className="mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-raised text-brand"><Icon n="chat" s={26} /></span>
                <p className="text-lg font-extrabold">Como posso ajudar hoje?</p><p className="mt-1 max-w-md text-sm text-mute">Escreva sua pergunta com suas palavras ou escolha uma da biblioteca ao lado.</p>
                <div className="mt-5 flex max-w-xl flex-wrap justify-center gap-2">{['Como organizar minha divisão de treino?', 'Como registrar minhas refeições?', 'Como selecionar minhas prioridades musculares?'].map((s) => <button key={s} onClick={() => send(s)} className="min-h-10 rounded-full border border-line px-4 text-xs font-semibold text-mute hover:border-brand hover:text-brand">{s}</button>)}</div>
              </div>
            ) : (
              <div className="space-y-4">
                {chat.msgs.map((m, i) => m.me ? (
                  <div key={i} className="rise flex justify-end"><p className="max-w-[85%] rounded-2xl rounded-br-md bg-accent px-4 py-2.5 text-sm font-semibold text-accent-ink">{m.text}</p></div>
                ) : (
                  <div key={i} className="rise flex gap-3"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-raised text-brand"><Icon n="spark" s={16} /></span>
                    <div className="min-w-0 max-w-[88%] rounded-2xl rounded-tl-md border border-line bg-raised px-4 py-3 text-sm">
                      <div className="mb-2 flex flex-wrap items-center gap-1.5">{m.kind && <Badge tone={KIND[m.kind][1]}>{KIND[m.kind][0]}</Badge>}{m.cat && <Badge>{m.cat}</Badge>}</div>
                      {m.title && <p className="mb-1.5 font-bold">{m.title}</p>}
                      {m.steps && <ol className="space-y-1.5 text-mute">{m.steps.map((s, j) => <li key={j} className="flex gap-2"><span className="num font-bold text-brand">{j + 1}.</span>{s}</li>)}</ol>}
                      {m.text && <p className={`text-mute ${m.steps ? 'mt-2' : ''}`}>{m.text}</p>}
                      <div className="mt-3 flex items-center justify-between gap-2 border-t border-line pt-2">
                        <span className="text-[11px] text-mute">{m.ref ? `Fonte: ${m.ref}` : 'Sem uso de dados pessoais'}</span>
                        <button onClick={() => copy(m)} className="flex h-9 items-center gap-1.5 rounded-lg px-2 text-xs font-bold text-mute hover:bg-surface hover:text-ink"><Icon n="edit" s={14} />Copiar</button>
                      </div></div></div>
                ))}
                {busy && <div className="flex gap-3" role="status" aria-label="Beyond AI está respondendo"><span className="flex h-8 w-8 items-center justify-center rounded-lg bg-raised text-brand"><Icon n="spark" s={16} /></span>
                  <div className="flex items-center gap-1.5 rounded-2xl bg-raised px-4 py-3">{[0, 1, 2].map((d) => <span key={d} className="dot h-1.5 w-1.5 rounded-full bg-mute" style={{ animationDelay: `${d * 0.2}s` }} />)}</div></div>}
                <div ref={end} />
              </div>
            )}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(t) }} className="border-t border-line p-3">
            {err && <p role="alert" className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-bad"><Icon n="alert" s={14} />{err}</p>}
            <div className="flex gap-2">
              <input aria-label="Mensagem para o Beyond AI" value={t} onChange={(e) => { setT(e.target.value); setErr('') }} placeholder="Pergunte qualquer coisa sobre treino, alimentação ou o app" className="h-12 min-w-0 flex-1 rounded-xl border border-control bg-bg px-4 text-sm placeholder:text-mute hover:border-mute focus:border-brand focus:outline-none" />
              <Button type="submit" className="h-12 w-12 !px-0" aria-label="Enviar mensagem" disabled={!t.trim()} loading={busy}>{!busy && <Icon n="send" s={18} />}</Button>
            </div>
          </form>
        </section>

        <aside className="rounded-card border border-line bg-surface lg:h-[calc(100dvh-17rem)] lg:overflow-hidden">
          <div role="tablist" aria-label="Painel" className="flex border-b border-line p-1.5">
            {([['lib', 'Biblioteca'], ['hist', `Histórico${chats.length ? ` (${chats.length})` : ''}`], ['ctx', 'Meus dados']] as const).map(([k, l]) => <button key={k} role="tab" aria-selected={panel === k} onClick={() => setPanel(k)} className={`h-10 flex-1 rounded-lg text-xs font-bold ${panel === k ? 'bg-raised text-ink' : 'text-mute hover:text-ink'}`}>{l}</button>)}
          </div>
          <div className="max-h-[560px] overflow-y-auto p-4 lg:h-[calc(100%-3.5rem)] lg:max-h-none">
            {panel === 'lib' && (<>
              <label className="relative block"><span className="sr-only">Buscar perguntas</span>
                <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar perguntas" className="h-11 w-full rounded-xl border border-control bg-bg px-3.5 text-sm placeholder:text-mute focus:border-brand focus:outline-none" /></label>
              <div className="-mx-1 my-3 flex gap-1.5 overflow-x-auto px-1 pb-1">
                {[{ id: 'todas', name: 'Todas' }, ...CATEGORIES].map((c) => <button key={c.id} aria-pressed={cat === c.id} onClick={() => setCat(c.id)} className={`h-9 shrink-0 rounded-full border px-3 text-xs font-bold ${cat === c.id ? 'border-brand bg-brand/10 text-brand' : 'border-line text-mute hover:text-ink'}`}>{c.name}</button>)}
              </div>
              {list.length === 0 ? <p className="rounded-xl border border-dashed border-line p-5 text-center text-sm text-mute">Nenhuma pergunta encontrada. Você pode escrever a sua no campo de mensagem.</p> : (
                <ul className="space-y-1.5">{list.map((x) => <li key={x.q}><button disabled={busy} onClick={() => send(x.q)} className="w-full rounded-xl px-3 py-2.5 text-left text-sm hover:bg-raised disabled:opacity-50"><span className="font-semibold">{x.q}</span>{cat === 'todas' && <span className="mt-0.5 block text-[11px] text-mute">{x.cat}</span>}</button></li>)}</ul>
              )}
            </>)}
            {panel === 'hist' && (chats.length === 0 ? <p className="rounded-xl border border-dashed border-line p-5 text-center text-sm text-mute">Suas conversas desta sessão aparecerão aqui. Elas não são salvas após recarregar a página.</p> : (
              <ul className="space-y-1.5">{chats.map((c) => (
                <li key={c.id} className={`flex items-center gap-1 rounded-xl ${c.id === cur ? 'bg-raised' : ''}`}>
                  <button onClick={() => setCur(c.id)} className="min-h-11 min-w-0 flex-1 truncate px-3 text-left text-sm font-semibold">{c.title}</button>
                  <IconButton label={`Excluir conversa ${c.title}`} n="trash" onClick={() => { setChats(chats.filter((x) => x.id !== c.id)); if (cur === c.id) setCur(null); toast('Conversa excluída', 'info') }} />
                </li>))}</ul>
            ))}
            {panel === 'ctx' && (<>
              <p className="text-sm text-mute">No futuro, o Beyond AI poderá usar dados seus para respostas personalizadas, somente com a sua autorização.</p>
              <ul className="mt-4 divide-y divide-line">{CONTEXT.map((c) => <li key={c} className="flex items-center justify-between gap-3 py-3"><span className="text-sm font-semibold">{c}</span><span className="opacity-50"><Toggle label={`Permitir uso de ${c}`} checked={false} onChange={() => toast('Disponível apenas com back-end e autenticação', 'info')} /></span></li>)}</ul>
              <p className="mt-3 flex gap-2 text-[11px] text-mute"><Icon n="info" s={14} className="shrink-0" />Indisponível no protótipo: nenhum dado seu é lido pelo assistente. As chaves de um modelo de IA ficariam no servidor, nunca no navegador.</p>
            </>)}
          </div>
        </aside>
      </div>
    </div>
  )
}
