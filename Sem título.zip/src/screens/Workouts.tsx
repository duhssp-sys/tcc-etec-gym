import { useState } from 'react'
import { useApp } from '../lib/store'
import { Badge, Button, Card, DemoTag, EmptyState, Field, Icon, IconButton, Modal, PageHeader, Segmented } from '../components/ui'
import { GROUPS, type Status, type Workout } from '../lib/data'
import { WorkoutSession } from './WorkoutSession'
import { Priorities } from './Priorities'

const ST: Record<Status, [string, 'accent' | 'info' | 'ok']> = { planejado: ['Planejado', 'accent'], andamento: ['Em andamento', 'info'], concluido: ['Concluído', 'ok'] }

export function Workouts() {
  const { workouts, setWorkouts, activeId, openWorkout, toast, view, priorities, go } = useApp()
  const [filter, setFilter] = useState<'todos' | Status>('todos')
  const [modal, setModal] = useState<Workout | 'new' | null>(null)
  const [name, setName] = useState('')
  const [groups, setGroups] = useState<string[]>([])
  const active = workouts.find((w) => w.id === activeId)
  if (active) return <WorkoutSession workout={active} />
  if (view === 'priorities') return <Priorities />

  const open = (w: Workout | 'new') => { setModal(w); setName(w === 'new' ? '' : w.name); setGroups(w === 'new' ? [] : w.groups) }
  const save = (e: React.FormEvent) => {
    e.preventDefault()
    if (modal === 'new') { setWorkouts([...workouts, { id: Math.random().toString(36).slice(2, 8), name: name.trim(), groups, minutes: 0, last: 'Nunca executado', status: 'planejado', exercises: [] }]); toast('Rotina criada') }
    else if (modal) { setWorkouts(workouts.map((w) => (w.id === modal.id ? { ...w, name: name.trim(), groups } : w))); toast('Rotina atualizada') }
    setModal(null)
  }
  const list = workouts.filter((w) => filter === 'todos' || w.status === filter)
  return (
    <div>
      <PageHeader title="Treinos" desc="Suas rotinas por grupo muscular. Inicie, continue ou ajuste cada treino." action={<div className="flex gap-2"><Button variant="secondary" onClick={() => go('train', 'priorities')}><Icon n="dumb" s={16} />Prioridades</Button><Button onClick={() => open('new')}><Icon n="plus" s={16} />Nova rotina</Button></div>} />
      <button onClick={() => go('train', 'priorities')} className="mb-5 flex w-full flex-wrap items-center gap-x-3 gap-y-2 rounded-card border border-line bg-surface px-4 py-3 text-left hover:border-mute">
        <span className="text-sm font-bold">Prioridades musculares</span>
        <span className="flex flex-1 flex-wrap gap-1.5">{priorities.length ? priorities.map((p) => <Badge key={p.id} tone={p.level === 'alta' ? 'accent' : 'neutral'}>{p.id}</Badge>) : <span className="text-xs text-mute">Nenhuma definida</span>}</span>
        <span className="flex items-center gap-1 text-xs font-bold text-brand">Ajustar<Icon n="right" s={14} /></span>
      </button>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <Segmented label="Filtrar por status" value={filter} onChange={setFilter} options={[['todos', 'Todos'], ['planejado', 'Planejados'], ['andamento', 'Em andamento'], ['concluido', 'Concluídos']]} />
        <DemoTag />
      </div>
      {list.length === 0 ? <EmptyState icon="dumb" title="Nenhum treino neste filtro" desc="Altere o filtro ou crie uma nova rotina para começar." action={<Button variant="secondary" onClick={() => setFilter('todos')}>Ver todos</Button>} /> : (
        <ul className="grid gap-4 md:grid-cols-2">
          {list.map((w) => {
            const [label, tone] = ST[w.status]
            return (
              <li key={w.id}><Card className={`flex h-full flex-col ${w.status === 'andamento' ? 'border-info/40' : ''}`}>
                <div className="flex items-start justify-between gap-2"><Badge tone={tone}>{w.status === 'concluido' && <Icon n="check" s={12} />}{label}</Badge>
                  <IconButton label={`Editar ${w.name}`} n="edit" onClick={() => open(w)} /></div>
                <h2 className="mt-2 text-xl font-extrabold tracking-tight">{w.name}</h2>
                <div className="mt-2 flex flex-wrap gap-1.5">{w.groups.map((g) => <span key={g} className="rounded-md bg-raised px-2 py-0.5 text-[11px] font-semibold text-mute">{g}</span>)}</div>
                <dl className="my-5 grid grid-cols-3 gap-3 text-xs">
                  <div><dt className="text-mute">Exercícios</dt><dd className="num mt-0.5 text-lg font-extrabold">{w.exercises.length}</dd></div>
                  <div><dt className="text-mute">Duração</dt><dd className="num mt-0.5 text-lg font-extrabold">{w.minutes ? `${w.minutes} min` : '—'}</dd></div>
                  <div><dt className="text-mute">Última vez</dt><dd className="mt-1 text-sm font-bold">{w.last}</dd></div>
                </dl>
                <div className="mt-auto flex gap-2">
                  <Button className="flex-1" variant={w.status === 'concluido' ? 'secondary' : 'primary'} disabled={!w.exercises.length} onClick={() => openWorkout(w.id)}>
                    <Icon n="play" s={14} />{w.status === 'andamento' ? 'Continuar' : w.status === 'concluido' ? 'Repetir' : 'Iniciar'}</Button>
                  <Button variant="secondary" onClick={() => openWorkout(w.id)}>Detalhes</Button>
                </div>
              </Card></li>
            )
          })}
        </ul>
      )}
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal === 'new' ? 'Nova rotina' : 'Editar rotina'}>
        <form onSubmit={save} className="space-y-4">
          <Field label="Nome da rotina" required placeholder="Ex.: Peito e Tríceps" value={name} onChange={(e) => setName(e.target.value)} />
          <fieldset><legend className="mb-1.5 text-xs font-semibold text-mute">Grupos musculares</legend>
            <div className="flex flex-wrap gap-2">{GROUPS.map((g) => { const on = groups.includes(g); return (
              <button type="button" key={g} aria-pressed={on} onClick={() => setGroups(on ? groups.filter((x) => x !== g) : [...groups, g])} className={`h-9 rounded-full border px-3.5 text-sm font-semibold ${on ? 'border-brand bg-brand/10 text-brand' : 'border-line text-mute hover:text-ink'}`}>{on && '✓ '}{g}</button>) })}</div></fieldset>
          <p className="text-xs text-mute">Os exercícios são adicionados dentro da rotina. Alterações valem apenas durante esta visita (protótipo).</p>
          <div className="flex justify-between gap-2 pt-1">
            {modal !== 'new' && modal ? <Button type="button" variant="danger" onClick={() => { setWorkouts(workouts.filter((w) => w.id !== modal.id)); setModal(null); toast('Rotina removida') }}><Icon n="trash" s={14} />Excluir</Button> : <span />}
            <div className="flex gap-2"><Button type="button" variant="ghost" onClick={() => setModal(null)}>Cancelar</Button><Button type="submit" disabled={!name.trim()}>Salvar</Button></div>
          </div>
        </form>
      </Modal>
    </div>
  )
}
