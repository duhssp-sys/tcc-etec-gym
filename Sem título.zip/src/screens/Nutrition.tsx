import { useState } from 'react'
import { useApp } from '../lib/store'
import { Button, Card, DemoTag, EmptyState, Field, Icon, IconButton, Modal, PageHeader, Progress, Ring, SectionTitle, Select } from '../components/ui'
import { GOALS, MEAL_TYPES, type Meal, type MealType } from '../lib/data'

const blank = { type: 'Lanche' as MealType, time: '16:00', desc: '', kcal: '', p: '', c: '', f: '' }

export function Nutrition() {
  const { meals, setMeals, water, addWater, toast } = useApp()
  const [offset, setOffset] = useState(0)
  const [modal, setModal] = useState<'new' | Meal | null>(null)
  const [f, setF] = useState(blank)
  const day = new Date(); day.setDate(day.getDate() + offset)
  const isToday = offset === 0
  const label = isToday ? 'Hoje' : offset === -1 ? 'Ontem' : day.toLocaleDateString('pt-BR', { weekday: 'long' })
  // Apenas o dia atual possui registros de demonstração; outros dias mostram o estado vazio.
  const list = isToday ? meals : []
  const tot = list.reduce((a, m) => ({ k: a.k + m.kcal, p: a.p + m.p, c: a.c + m.c, f: a.f + m.f }), { k: 0, p: 0, c: 0, f: 0 })
  const set = (k: keyof typeof blank) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value })
  const open = (m: 'new' | Meal) => { setModal(m); setF(m === 'new' ? blank : { type: m.type, time: m.time, desc: m.desc, kcal: String(m.kcal), p: String(m.p), c: String(m.c), f: String(m.f) }) }
  const save = (e: React.FormEvent) => {
    e.preventDefault()
    const data = { type: f.type, time: f.time, desc: f.desc.trim(), kcal: +f.kcal, p: +f.p || 0, c: +f.c || 0, f: +f.f || 0 }
    if (modal === 'new') { setMeals([...meals, { id: Math.random().toString(36).slice(2, 8), ...data }]); toast('Refeição registrada') }
    else if (modal) { setMeals(meals.map((m) => (m.id === modal.id ? { ...m, ...data } : m))); toast('Registro atualizado') }
    setModal(null)
  }
  return (
    <div>
      <PageHeader title="Alimentação" desc="Registre o que você comeu e acompanhe o dia. Valores são estimativas informadas por você." action={isToday ? <Button onClick={() => open('new')}><Icon n="plus" s={16} />Registrar refeição</Button> : undefined} />
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 rounded-xl border border-line bg-surface p-1">
          <IconButton label="Dia anterior" n="left" onClick={() => setOffset(offset - 1)} />
          <span className="min-w-36 text-center text-sm font-bold capitalize">{label}<span className="block text-[11px] font-medium text-mute">{day.toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })}</span></span>
          <IconButton label="Próximo dia" n="right" disabled={isToday} onClick={() => setOffset(offset + 1)} />
        </div>
        <DemoTag />
      </div>
      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          {!isToday && list.length === 0 ? <EmptyState icon="food" title="Sem registros neste dia" desc="Este protótipo guarda apenas os registros da sessão atual. Volte para hoje para registrar refeições." action={<Button variant="secondary" onClick={() => setOffset(0)}>Ir para hoje</Button>} /> :
            MEAL_TYPES.map((t) => {
              const items = list.filter((m) => m.type === t).sort((a, b) => a.time.localeCompare(b.time))
              return (
                <Card key={t} className="!p-4">
                  <div className="mb-2 flex items-center justify-between"><h2 className="font-bold">{t}</h2><span className="num text-xs font-semibold text-mute">{items.reduce((a, m) => a + m.kcal, 0)} kcal</span></div>
                  {items.length === 0 ? (
                    <button onClick={() => { setModal('new'); setF({ ...blank, type: t, time: '12:00' }) }} className="flex h-14 w-full items-center justify-center gap-2 rounded-xl border border-dashed border-line text-sm font-semibold text-mute hover:border-brand hover:text-brand"><Icon n="plus" s={16} />Ainda não registrado. Adicionar</button>
                  ) : (
                    <ul className="divide-y divide-line">{items.map((m) => (
                      <li key={m.id} className="flex items-center gap-3 py-3">
                        <span className="num w-12 text-sm font-bold text-mute">{m.time}</span>
                        <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{m.desc || t}</p><p className="num text-xs text-mute">P {m.p} g · C {m.c} g · G {m.f} g</p></div>
                        <span className="num text-sm font-bold">{m.kcal}</span>
                        <IconButton label={`Editar ${t} das ${m.time}`} n="edit" onClick={() => open(m)} />
                        <IconButton label={`Remover ${t} das ${m.time}`} n="trash" onClick={() => { setMeals(meals.filter((x) => x.id !== m.id)); toast('Registro removido', 'info') }} />
                      </li>))}</ul>
                  )}
                </Card>
              )
            })}
        </div>
        <aside className="space-y-4 lg:sticky lg:top-6 lg:self-start">
          <Card>
            <SectionTitle title="Resumo do dia" />
            <div className="flex justify-center"><Ring value={tot.k} max={GOALS.kcal} size={150} label={`${tot.k} de ${GOALS.kcal} calorias`}><span className="num text-3xl font-extrabold">{tot.k}</span><span className="text-xs text-mute">de {GOALS.kcal} kcal</span></Ring></div>
            <div className="mt-5 space-y-3 text-xs">{([['Proteína', tot.p, GOALS.p], ['Carboidrato', tot.c, GOALS.c], ['Gordura', tot.f, GOALS.f]] as const).map(([l, v, g]) => (
              <div key={l}><div className="mb-1 flex justify-between"><span className="text-mute">{l}</span><span className="num font-bold">{v}/{g} g</span></div><Progress value={v} max={g} label={l} /></div>))}</div>
            <p className="mt-4 text-[11px] leading-relaxed text-mute">Metas de exemplo para a interface. Não constituem prescrição nutricional.</p>
          </Card>
          <Card>
            <SectionTitle title="Hidratação" />
            <p className="num text-2xl font-extrabold">{(water / 1000).toFixed(2).replace('.', ',')} <span className="text-sm text-mute">/ {GOALS.water / 1000} L</span></p>
            <div className="my-3"><Progress tone="info" value={water} max={GOALS.water} label="Hidratação diária" /></div>
            <div className="flex gap-2"><Button size="sm" variant="secondary" aria-label="Remover 250 ml" onClick={() => addWater(-250)}><Icon n="minus" s={14} /></Button>
              <Button size="sm" variant="secondary" className="flex-1" onClick={() => { addWater(250); toast('+250 ml registrados') }}><Icon n="drop" s={14} />+250 ml</Button></div>
          </Card>
        </aside>
      </div>
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal === 'new' ? 'Registrar refeição' : 'Editar refeição'}>
        <form onSubmit={save} className="space-y-4">
          <div className="grid grid-cols-2 gap-3"><Select label="Período" value={f.type} onChange={set('type')}>{MEAL_TYPES.map((t) => <option key={t}>{t}</option>)}</Select><Field label="Horário" type="time" required value={f.time} onChange={set('time')} /></div>
          <Field label="O que você comeu" required placeholder="Ex.: Iogurte natural com frutas" value={f.desc} onChange={set('desc')} />
          <div className="grid grid-cols-4 gap-2"><Field label="kcal" required type="number" min="0" value={f.kcal} onChange={set('kcal')} /><Field label="Prot. (g)" type="number" min="0" value={f.p} onChange={set('p')} /><Field label="Carb. (g)" type="number" min="0" value={f.c} onChange={set('c')} /><Field label="Gord. (g)" type="number" min="0" value={f.f} onChange={set('f')} /></div>
          <div className="flex justify-end gap-2"><Button type="button" variant="ghost" onClick={() => setModal(null)}>Cancelar</Button><Button type="submit">Salvar</Button></div>
        </form>
      </Modal>
    </div>
  )
}
