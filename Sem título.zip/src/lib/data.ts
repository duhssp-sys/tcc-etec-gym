// Dados DEMONSTRATIVOS: exemplos de interface, não são registros reais nem persistentes.
export type Status = 'planejado' | 'andamento' | 'concluido'
export type Exercise = { id: string; name: string; group: string; sets: number; reps: number; kg: number; rest: number }
export type Workout = { id: string; name: string; groups: string[]; minutes: number; last: string; status: Status; exercises: Exercise[] }
export type MealType = 'Café da manhã' | 'Almoço' | 'Lanche' | 'Jantar'
export type Meal = { id: string; type: MealType; time: string; desc: string; kcal: number; p: number; c: number; f: number }

export const MEAL_TYPES: MealType[] = ['Café da manhã', 'Almoço', 'Lanche', 'Jantar']
export const GOALS = { kcal: 2200, p: 140, c: 260, f: 70, water: 2500 }
export const GROUPS = ['Peito', 'Costas', 'Ombros', 'Bíceps', 'Tríceps', 'Quadríceps', 'Posterior de coxa', 'Glúteos', 'Panturrilhas', 'Abdômen']

const ex = (id: string, name: string, group: string, sets: number, reps: number, kg: number, rest: number): Exercise => ({ id, name, group, sets, reps, kg, rest })

export const WORKOUTS: Workout[] = [
  { id: 'w1', name: 'Peito e Tríceps', groups: ['Peito', 'Tríceps'], minutes: 55, last: 'Há 3 dias', status: 'planejado', exercises: [
    ex('a', 'Supino reto', 'Peito', 4, 10, 40, 90), ex('b', 'Supino inclinado', 'Peito', 3, 10, 30, 90), ex('c', 'Crucifixo', 'Peito', 3, 12, 12, 60), ex('d', 'Tríceps corda', 'Tríceps', 3, 12, 20, 60)] },
  { id: 'w2', name: 'Costas e Bíceps', groups: ['Costas', 'Bíceps'], minutes: 50, last: 'Há 5 dias', status: 'andamento', exercises: [
    ex('a', 'Puxada frontal', 'Costas', 4, 10, 45, 90), ex('b', 'Remada baixa', 'Costas', 3, 12, 40, 60), ex('c', 'Rosca direta', 'Bíceps', 3, 10, 15, 60)] },
  { id: 'w3', name: 'Quadríceps', groups: ['Quadríceps', 'Abdômen'], minutes: 65, last: 'Ontem', status: 'concluido', exercises: [
    ex('a', 'Agachamento', 'Quadríceps', 4, 8, 60, 120), ex('b', 'Leg press', 'Quadríceps', 4, 12, 120, 90), ex('c', 'Cadeira extensora', 'Quadríceps', 3, 12, 35, 60), ex('d', 'Prancha', 'Abdômen', 3, 1, 0, 45)] },
  { id: 'w4', name: 'Ombros', groups: ['Ombros'], minutes: 40, last: 'Há 8 dias', status: 'planejado', exercises: [
    ex('a', 'Desenvolvimento', 'Ombros', 4, 10, 20, 90), ex('b', 'Elevação lateral', 'Ombros', 3, 12, 8, 60)] },
]

export const MEALS: Meal[] = [
  { id: 'm1', type: 'Café da manhã', time: '07:30', desc: 'Ovos mexidos, pão integral e mamão', kcal: 460, p: 28, c: 52, f: 14 },
  { id: 'm2', type: 'Almoço', time: '12:40', desc: 'Arroz, feijão, frango grelhado e salada', kcal: 720, p: 48, c: 82, f: 18 },
]

export const WEEK = [
  { d: 'Seg', min: 55, done: true }, { d: 'Ter', min: 0, done: false }, { d: 'Qua', min: 50, done: true },
  { d: 'Qui', min: 65, done: true }, { d: 'Sex', min: 0, done: false }, { d: 'Sáb', min: 0, done: false }, { d: 'Dom', min: 0, done: false },
]

export const HISTORY = {
  '7d': { freq: [3, 4, 3, 5, 4, 3, 4], label: 'Últimos 7 dias' },
  '30d': { freq: [3, 4, 4, 3, 5], label: 'Últimas 5 semanas' },
  '90d': { freq: [] as number[], label: 'Últimos 90 dias' },
}
export const LOAD_SERIES = [{ x: 'Sem 1', y: 30 }, { x: 'Sem 2', y: 32.5 }, { x: 'Sem 3', y: 35 }, { x: 'Sem 4', y: 35 }, { x: 'Sem 5', y: 40 }]
export const SESSIONS = [
  { date: '12/06', name: 'Quadríceps', min: 65 }, { date: '10/06', name: 'Costas e Bíceps', min: 50 },
  { date: '08/06', name: 'Peito e Tríceps', min: 55 }, { date: '05/06', name: 'Ombros', min: 42 },
]
