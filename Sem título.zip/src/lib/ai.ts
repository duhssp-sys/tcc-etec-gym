import { EXERCISES } from './exercises'
import type { ChatMsg } from './store'

// Biblioteca PRÉ-CADASTRADA do protótipo. Não há modelo de IA conectado: as respostas são textos fixos.
export type QA = { q: string; a: string[] }
export type Category = { id: string; name: string; icon: string; qs: QA[] }
const qa = (q: string, ...a: string[]): QA => ({ q, a })

export const CATEGORIES: Category[] = [
  { id: 'treinos', name: 'Treinos', icon: 'dumb', qs: [
    qa('Como organizar minha divisão de treino?', 'Escolha a divisão conforme os dias que você consegue treinar de forma constante.', 'Com 2 a 3 dias, o full body costuma funcionar bem; com 4 dias, AB ou upper/lower; com 5 ou mais, divisões por grupo muscular.', 'Em Treinos, crie uma rotina para cada dia e use as prioridades musculares como referência.'),
    qa('Como escolher os exercícios?', 'Comece pelos movimentos principais do grupo muscular (ex.: supino para peito, puxada para costas) e complemente com exercícios mais específicos.', 'O catálogo do Beyond Training mostra grupo muscular, equipamento e orientações de cada exercício.'),
    qa('Quantas vezes treinar cada grupo muscular?', 'De forma geral, muitas rotinas trabalham cada grupo de 1 a 2 vezes por semana, com descanso entre as sessões.', 'A frequência ideal depende do seu nível e objetivo; um profissional de Educação Física pode ajustar isso para você.'),
    qa('Como organizar um treino de corpo inteiro?', 'Distribua um exercício principal para cada grande região: pernas, peito, costas, ombros e abdômen.', 'Comece pelos exercícios mais exigentes e mantenha o volume moderado para conseguir manter a técnica.'),
    qa('Como distribuir os grupos musculares durante a semana?', 'Evite treinar o mesmo grupo em dias seguidos e alterne regiões (ex.: empurrar, puxar, pernas).', 'Em Treinos > Prioridades, veja um exemplo ilustrativo de distribuição semanal baseado nas suas escolhas.'),
    qa('Como registrar minha carga?', 'Abra o treino, inicie a sessão e use os botões − e + do campo Carga (kg) de cada exercício.', 'As alterações valem na sessão atual do protótipo; o histórico persistente depende do back-end.'),
    qa('Como acompanhar minhas séries e repetições?', 'Durante a sessão, toque em Série para registrar cada série concluída. O progresso do treino mostra séries feitas e restantes.'),
    qa('Como ajustar uma rotina de treinamento?', 'Em Treinos, toque no ícone de edição da rotina para renomear, alterar grupos ou excluir.', 'Dentro do treino você pode adicionar ou remover exercícios.'),
    qa('Qual a diferença entre divisões AB, ABC e full body?', 'AB divide o treino em dois blocos alternados; ABC em três; full body trabalha o corpo todo em cada sessão.', 'Mais dias de treino permitem divisões mais específicas; menos dias favorecem o full body.'),
    qa('Como substituir um exercício se não houver o equipamento?', 'Procure outro exercício do mesmo grupo muscular com equipamento diferente (ex.: halteres no lugar de máquina).', 'Em Adicionar exercício, escolha o grupo e veja as alternativas disponíveis.'),
  ] },
  { id: 'execucao', name: 'Execução de exercícios', icon: 'play', qs: [
    qa('Como executar determinado exercício?', 'Digite o nome do exercício (ex.: "como fazer agachamento") e mostro os passos gerais cadastrados.', 'Você também pode abrir a demonstração animada dentro do treino.'),
    qa('Qual músculo é trabalhado?', 'Cada exercício do catálogo informa o grupo muscular principal e os secundários na tela de demonstração.', 'Pergunte pelo nome do exercício para ver o detalhe.'),
    qa('Qual equipamento devo utilizar?', 'O catálogo indica o equipamento de cada exercício: barra, halteres, polia, máquina ou peso corporal.', 'Se não houver o equipamento, escolha um exercício equivalente do mesmo grupo.'),
    qa('Quais erros comuns devo evitar?', 'Usar impulso em vez de controle, reduzir a amplitude sem necessidade e deixar a postura perder o alinhamento.', 'Cada exercício lista erros comuns específicos na demonstração.'),
    qa('Como funciona a amplitude do movimento?', 'Amplitude é o quanto a articulação se move do início ao fim. O ideal é a maior amplitude que você controla com boa postura, sem dor.', 'Se sentir dor, interrompa e procure um profissional.'),
    qa('Como utilizar a animação demonstrativa?', 'No treino, toque no ícone de reprodução do exercício. Use play/pause, a barra de posição e a velocidade (0,5x, 1x, 1,5x).', 'Exercícios sem animação mostram um aviso e as orientações escritas.'),
    qa('Como identificar a posição inicial e final?', 'O avatar indica a fase atual: Posição inicial, execução, Posição final e retorno. Pause e arraste a barra de posição para observar cada ponto.'),
    qa('Como respirar durante a execução?', 'De modo geral, expira-se no esforço e inspira-se no retorno, sem prender a respiração por longos períodos.', 'Se tiver dúvidas específicas, converse com um profissional.'),
    qa('A demonstração visual substitui orientação presencial?', 'Não. A animação é um apoio visual estilizado; um profissional de Educação Física avalia sua técnica e adapta o exercício a você.'),
  ] },
  { id: 'alimentacao', name: 'Alimentação e hidratação', icon: 'food', qs: [
    qa('Como organizar minhas refeições?', 'Defina horários possíveis na sua rotina e registre cada refeição no período correspondente: café da manhã, almoço, lanche e jantar.', 'O diário ajuda a observar seus hábitos ao longo da semana.'),
    qa('O que são proteínas, carboidratos e gorduras?', 'São os macronutrientes: proteínas participam da construção e reparo dos tecidos, carboidratos são fonte de energia e gorduras auxiliam funções do organismo.', 'Informação geral e educativa, não é recomendação individual.'),
    qa('Qual a diferença entre macronutrientes e micronutrientes?', 'Macronutrientes (proteínas, carboidratos, gorduras) fornecem energia em maior quantidade. Micronutrientes (vitaminas e minerais) são necessários em quantidades menores.'),
    qa('Como registrar minhas refeições?', 'Em Alimentação, toque em Registrar refeição, escolha o período, horário, descrição e estimativas de calorias e macros.', 'Você pode editar ou remover cada registro depois.'),
    qa('Como acompanhar minha ingestão de água?', 'Use os botões +250 ml e +500 ml no painel de Hidratação, na Visão geral ou em Alimentação.'),
    qa('Como organizar uma alimentação equilibrada?', 'De forma geral, combine alimentos variados e minimamente processados ao longo do dia.', 'Planos alimentares individualizados devem ser feitos por nutricionista.'),
    qa('Como consultar meus registros alimentares?', 'Em Alimentação, navegue entre os dias com as setas ao lado da data.', 'O histórico de longo prazo depende de persistência de dados, ainda não implementada.'),
    qa('Como planejar refeições de acordo com minha rotina?', 'Observe seus horários de treino e trabalho e registre refeições nesses períodos para identificar lacunas.', 'Para metas e quantidades individuais, procure um nutricionista.'),
    qa('Pode sugerir ideias de refeições e lanches?', 'Ideias gerais: ovos com pão integral e fruta, arroz com feijão e proteína com salada, iogurte com frutas, sanduíche simples.', 'São exemplos informativos, sem prescrição.'),
  ] },
  { id: 'progresso', name: 'Progresso', icon: 'prog', qs: [
    qa('Como acompanhar minha evolução?', 'Em Progresso, veja frequência semanal, duração das sessões e evolução de carga, com filtros de 7, 30 e 90 dias.'),
    qa('Como comparar meus treinos?', 'Compare duração e frequência no gráfico semanal e as últimas sessões listadas em Progresso.'),
    qa('Como consultar meu histórico?', 'A lista Últimas sessões mostra data, rotina e duração.', 'O histórico completo persistente depende do back-end.'),
    qa('Como acompanhar minha frequência semanal?', 'O gráfico Frequência semanal conta os treinos concluídos por semana no período escolhido.'),
    qa('Como identificar evolução de carga?', 'O gráfico de evolução de carga mostra a maior carga registrada por semana em um exercício. Ele indica desempenho, não condição física.'),
    qa('O que significa o indicador de consistência?', 'Mostra em quantas semanas você cumpriu a meta de treinos. É um indicador de atividade, não de resultado físico.'),
    qa('Como gerar meu relatório mensal?', 'Em Progresso > Compartilhar evolução, escolha o período Mensal e exporte o cartão como imagem.', 'Relatórios completos em PDF ainda não existem.'),
    qa('Como compartilhar minha evolução?', 'Em Progresso, toque em Compartilhar evolução, escolha período, formato e quais informações exibir, e baixe ou compartilhe a imagem.'),
    qa('Como comparar períodos diferentes?', 'Alterne entre 7, 30 e 90 dias em Progresso. Períodos sem dados suficientes mostram um aviso em vez de gráficos.'),
  ] },
  { id: 'habitos', name: 'Hábitos e rotina', icon: 'flame', qs: [
    qa('Como manter consistência?', 'Defina metas pequenas e realistas, escolha horários fixos e comece pelo que você consegue repetir toda semana.'),
    qa('Como organizar meus horários de treino?', 'Escolha horários que se encaixem em sua rotina e proteja-os como compromissos. Lembretes ajudam, e eles podem ser ativados em Configurações.'),
    qa('Qual a importância do descanso?', 'O descanso permite recuperação entre sessões. Dormir bem e respeitar dias de recuperação ajudam a manter regularidade.', 'Sinais persistentes de cansaço ou dor merecem avaliação profissional.'),
    qa('Como acompanhar minhas metas?', 'A Visão geral mostra o progresso semanal. Em Configurações você define quantos treinos pretende fazer por semana.'),
    qa('Como criar uma rotina sustentável?', 'Prefira poucos treinos que você consegue cumprir a um plano ambicioso demais. Aumente gradualmente.'),
    qa('Como organizar meus dias de recuperação?', 'Intercale dias de treino com dias livres ou mais leves, evitando grupos musculares repetidos em dias seguidos.'),
    qa('Como estabelecer objetivos realistas?', 'Defina objetivos mensuráveis e de prazo curto (ex.: treinar 3x por semana por um mês) e revise periodicamente.'),
    qa('Como retomar a rotina após faltar alguns dias?', 'Volte com cargas e volume mais leves, sem tentar compensar os dias perdidos, e reconstrua a frequência aos poucos.'),
  ] },
  { id: 'plataforma', name: 'Plataforma Beyond Training', icon: 'cog', qs: [
    qa('Como cadastrar um treino?', 'Em Treinos, toque em Nova rotina, dê um nome e escolha os grupos musculares. Depois adicione os exercícios.'),
    qa('Como editar minha rotina?', 'Em Treinos, use o ícone de edição no cartão da rotina.'),
    qa('Como selecionar minhas prioridades musculares?', 'Em Treinos, toque em Prioridades. Selecione grupos no corpo ou na lista, defina Alta, Média ou Baixa, reordene e salve.'),
    qa('Como registrar uma refeição?', 'Vá em Alimentação e toque em Registrar refeição.'),
    qa('Como utilizar o assistente?', 'Escolha uma pergunta da biblioteca, pesquise por tema ou escreva sua dúvida. Cada resposta indica que é uma simulação.'),
    qa('Como alterar meu tema?', 'Use o botão de tema na barra lateral (ou no topo, no celular), ou vá em Configurações > Aparência para escolher Escuro ou Claro.'),
    qa('Como acessar meus relatórios?', 'Os resumos ficam em Progresso, e você pode transformá-los em cartões em Compartilhar evolução.'),
    qa('Como compartilhar meus resultados?', 'Em Progresso > Compartilhar evolução. Você escolhe o que exibir; seu nome fica oculto por padrão.'),
    qa('Quais dados do app são usados e onde ficam?', 'Neste protótipo os dados são demonstrativos e ficam só em memória, exceto a preferência de tema. Em uma versão real, o uso de dados exigirá sua autorização e armazenamento seguro.'),
  ] },
]
export const ALL_QS = CATEGORIES.flatMap((c) => c.qs.map((x) => ({ ...x, cat: c.name })))

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
const STOP = new Set(['como', 'qual', 'quais', 'que', 'para', 'meu', 'minha', 'minhas', 'meus', 'uma', 'um', 'de', 'do', 'da', 'os', 'as', 'em', 'no', 'na', 'e', 'o', 'a', 'com', 'por', 'ao', 'se', 'ou', 'eu', 'posso', 'devo', 'pode'])
const tokens = (s: string) => norm(s).split(/[^a-z0-9]+/).filter((w) => w.length > 2 && !STOP.has(w))
const SAFETY = /\b(dor|dores|doi|lesao|lesionei|machuc\w*|sintoma\w*|doenca|diabet\w*|hipertens\w*|pressao alta|medicamento\w*|remedio\w*|diagnostic\w*|tratamento|gestante|gravida|cirurgia|anabolizante\w*|hormonio\w*|tontura|desmai\w*|dieta para|emagrecer \d+)/

export function answer(text: string): ChatMsg {
  const n = norm(text)
  if (SAFETY.test(n)) return { me: false, kind: 'safety', title: 'Isso pede avaliação profissional', text: 'Perguntas sobre dor, lesão, sintomas, doenças, medicamentos ou planos alimentares individuais precisam de avaliação de um profissional habilitado (médico, nutricionista ou profissional de Educação Física). Não posso diagnosticar nem indicar tratamento. Se houver dor intensa ou sintomas persistentes, interrompa o exercício e procure atendimento.' }
  const ex = Object.keys(EXERCISES).find((k) => n.includes(norm(k)))
  if (ex) { const i = EXERCISES[ex]; return { me: false, kind: 'sim', cat: 'Execução de exercícios', title: ex, steps: i.steps, text: `Grupo: ${i.group}${i.secondary.length ? ` (+ ${i.secondary.join(', ')})` : ''} · Equipamento: ${i.equip}. Erros comuns: ${i.errors.join('; ')}.${i.anim ? ' Há demonstração animada no treino.' : ' A animação deste exercício ainda não está disponível.'}`, ref: 'Catálogo de exercícios do Beyond Training' } }
  const q = tokens(text)
  let best: { s: number; item: (typeof ALL_QS)[number] } | null = null
  for (const item of ALL_QS) {
    const t = new Set(tokens(item.q + ' ' + item.a.join(' ')))
    const tq = new Set(tokens(item.q))
    const s = q.reduce((a, w) => a + (tq.has(w) ? 2 : t.has(w) ? 1 : 0), 0)
    if (!best || s > best.s) best = { s, item }
  }
  if (best && best.s >= 2) return { me: false, kind: 'sim', cat: best.item.cat, title: best.item.q, steps: best.item.a.length > 1 ? best.item.a : undefined, text: best.item.a.length > 1 ? undefined : best.item.a[0], ref: 'Biblioteca de perguntas (conteúdo pré-cadastrado)' }
  if (/\b(meus? (treino|dados|historico|refeic\w*)|minha (carga|frequencia|evolucao)|quanto (eu )?(treinei|comi))/.test(n)) return { me: false, kind: 'nodata', title: 'Ainda não consigo consultar seus dados', text: 'O acesso aos seus treinos, cargas e refeições exige integração com o back-end e sua autorização, o que ainda não existe neste protótipo. Você pode ver essas informações diretamente em Progresso e Alimentação.' }
  return { me: false, kind: 'nodata', title: 'Não encontrei uma resposta', text: 'Não tenho conteúdo cadastrado para essa pergunta. Tente reformular ou explore a biblioteca por categoria. Para orientações personalizadas, procure um profissional.' }
}
