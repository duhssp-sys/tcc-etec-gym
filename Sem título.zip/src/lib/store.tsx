import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react'
import { MEALS, WORKOUTS, GOALS, type Meal, type Workout } from './data'

export type Page = 'home' | 'train' | 'food' | 'prog' | 'chat' | 'settings'
export type Theme = 'dark' | 'light'
export type Level = 'alta' | 'media' | 'baixa'
export type Priority = { id: string; level: Level }
export type ChatMsg = { me: boolean; text?: string; title?: string; steps?: string[]; kind?: 'sim' | 'safety' | 'nodata' | 'error'; cat?: string; ref?: string }
export type Chat = { id: string; title: string; msgs: ChatMsg[] }
type Toast = { id: number; msg: string; tone: 'ok' | 'info' | 'bad' }

// A preferência de tema é a única informação gravada no navegador (localStorage).
// Todo o restante fica apenas em memória: recarregar a página restaura os dados demonstrativos.
const readTheme = (): Theme => { try { return localStorage.getItem('bt:theme') === 'light' ? 'light' : 'dark' } catch { return 'dark' } }
export const applyTheme = (t: Theme) => document.documentElement.classList.toggle('light', t === 'light')

type Ctx = {
  page: Page; view: string | null; go: (p: Page, view?: string) => void
  theme: Theme; setTheme: (t: Theme) => void
  workouts: Workout[]; setWorkouts: (w: Workout[]) => void
  activeId: string | null; demoEx: string | null; openWorkout: (id: string | null, demoEx?: string) => void
  priorities: Priority[]; setPriorities: (p: Priority[]) => void
  meals: Meal[]; setMeals: (m: Meal[]) => void
  water: number; addWater: (ml: number) => void
  chats: Chat[]; setChats: (c: Chat[]) => void
  toast: (msg: string, tone?: Toast['tone']) => void
  toasts: Toast[]
}
const C = createContext<Ctx>(null!)
export const useApp = () => useContext(C)

export function AppProvider({ children }: { children: ReactNode }) {
  const [page, setPage] = useState<Page>('home')
  const [view, setView] = useState<string | null>(null)
  const [theme, setThemeState] = useState<Theme>(readTheme)
  const [workouts, setWorkouts] = useState(WORKOUTS)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [demoEx, setDemoEx] = useState<string | null>(null)
  const [priorities, setPriorities] = useState<Priority[]>([{ id: 'Peito', level: 'alta' }, { id: 'Costas', level: 'alta' }, { id: 'Quadríceps', level: 'media' }, { id: 'Ombros', level: 'baixa' }])
  const [meals, setMeals] = useState(MEALS)
  const [water, setWater] = useState(1000)
  const [chats, setChats] = useState<Chat[]>([])
  const [toasts, setToasts] = useState<Toast[]>([])
  useEffect(() => { applyTheme(theme) }, [theme])
  const setTheme = (t: Theme) => { setThemeState(t); try { localStorage.setItem('bt:theme', t) } catch { /* sem armazenamento disponível */ } }
  const toast = useCallback((msg: string, tone: Toast['tone'] = 'ok') => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, msg, tone }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200)
  }, [])
  const go = (p: Page, v?: string) => { setPage(p); setView(v ?? null); setActiveId(null); setDemoEx(null); window.scrollTo({ top: 0 }) }
  const openWorkout = (id: string | null, ex?: string) => { setActiveId(id); setDemoEx(ex ?? null); setView(null); if (id) { setPage('train'); window.scrollTo({ top: 0 }) } }
  const addWater = (ml: number) => setWater((w) => Math.max(0, Math.min(GOALS.water * 1.5, w + ml)))
  return <C.Provider value={{ page, view, go, theme, setTheme, workouts, setWorkouts, activeId, demoEx, openWorkout, priorities, setPriorities, meals, setMeals, water, addWater, chats, setChats, toast, toasts }}>{children}</C.Provider>
}
