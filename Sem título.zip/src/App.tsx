import { AppProvider, useApp } from './lib/store'
import { Shell } from './components/Shell'
import { Dashboard } from './screens/Dashboard'
import { Workouts } from './screens/Workouts'
import { Nutrition } from './screens/Nutrition'
import { Progress } from './screens/Progress'
import { Assistant } from './screens/Assistant'
import { Settings } from './screens/Settings'

const SCREENS = { home: Dashboard, train: Workouts, food: Nutrition, prog: Progress, chat: Assistant, settings: Settings }

function Router() {
  const { page } = useApp()
  const Screen = SCREENS[page]
  return <Shell><Screen /></Shell>
}
export default function App() {
  return <AppProvider><Router /></AppProvider>
}
